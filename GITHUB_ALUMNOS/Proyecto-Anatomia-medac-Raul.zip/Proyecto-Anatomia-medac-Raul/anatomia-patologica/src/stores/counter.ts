import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useCounterStore = defineStore('counter', () => {
  const count = ref(0)
  const doubleCount = computed(() => count.value * 2)
  function increment() {
    count.value++
  }

/*
  const img = ref(null) // almacenar url
  const images = ref([]) // almacena imgs
  const formData = ref({}) //  info de formData 

  
  function setFormData(data) {
    formData.value = data
  }

  function addImage(image) {
    images.value.push(image)
  }
  */

  return { count, doubleCount, increment }
})
