<template>
  <div class="consultas-container">
    <div class="tt-cabecera"></div>
    <div class="tt-imagen-consultas">
      <p class="texto-tt-consultas">EDITAR INFORMES</p>
    </div>
    <div class="conten-gris">
      <div class="contenedor-txt-anadir">
        <div class="consulta-estado-informe">
          <div class="tt-estado-informe">
            <h2>Estado del Informe</h2>
          </div>
          <div class="estado-informe">
            <h4>Estado del informe:</h4>
            <select
              class="select-input"
              v-model="selectedEstadoInforme"
              :style="{ color: getColor(selectedEstadoInforme) }"
            >
              <option
                v-for="option3 in optionsEstadoInforme"
                :key="option3.value"
                :value="option3.value"
              >
                {{ option3.text }}
              </option>
            </select>
          </div>
        </div>
      </div>

      <div class="contenedor-txt-editar">
        <div class="cod-fecha-user">
          <div class="codigo">
            <p>Código:</p>
            <input type="text" class="textfield-input" />
          </div>
          <div class="fecha">
            <p>Fecha:</p>
          </div>
          <div class="calendar">
            <input type="date" class="date-input" v-model="selectedDate" onkeydown="return false" />
          </div>
          <div class="usuario">
            <p>Usuario:</p>
            <input type="text" class="txtUsuario-input" />
          </div>
        </div>

        <div class="img-placa"></div>
      </div>
      <div class="contenedor-txt-consulta">
        <div class="consultar-muestra">
          <div class="editar-muestra">
            <div class="muestra">
              <h4>Naturaleza de la muestra</h4>
              <select class="select-input" v-model="selectedOption1">
                <option
                  v-for="option1 in optionsNaturaleza"
                  :key="option1.value"
                  :value="option1.value"
                  v-bind:style="{
                    'font-weight':
                      option1.value === '1' || option1.value === '2' ? 'bold' : 'normal',
                    color: option1.value === '1' || option1.value === '2' ? '#004676' : '#004676'
                  }"
                >
                  {{ option1.text }}
                </option>
              </select>
            </div>

            <div class="tipo-muestra">
              <h4>Tipo de estudio</h4>
              <select class="select-input" v-model="selectedOption6">
                <option v-for="option6 in tipoEstudio" :key="option6.value" :value="option6.value">
                  {{ option6.text }}
                </option>
              </select>
            </div>

            <div class="muestra">
              <h4>Conservación de la Muestra</h4>
              <select class="select-input" v-model="selectedOption3">
                <option
                  v-for="option3 in optionsConservacion"
                  :key="option3.value"
                  :value="option3.value"
                >
                  {{ option3.text }}
                </option>
              </select>
            </div>
          </div>
          <div class="tipo-muestra-tt-descrip">
            <div class="muestra">
              <div class="tip-org" v-if="selectedOption1 === '1' || selectedOption1 === '2'">
                <h4>Tipo de Órgano</h4>
              </div>
              <select
                class="cmb-TipoOrgano"
                v-model="selectedOption2"
                v-if="selectedOption1 === '1' || selectedOption1 === '2'"
              >
                <option v-for="option2 in tipoOrgano" :key="option2.value" :value="option2.value">
                  {{ option2.text }}
                </option>
              </select>
            </div>
          </div>
          <div class="texto-descrip">
            <h3>Descripción citológica o tisular de la muestra</h3>
          </div>
          <div class="editar-muestra-vert">
            <div class="muestra-calidad">
              <h4>Calidad</h4>
              <select class="select-input-calidad" v-model="selectedOption4">
                <option v-for="option4 in options4" :key="option4.value" :value="option4.value">
                  {{ option4.text }}
                </option>
              </select>
            </div>
            <p class="caja-txt">
              “Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
              incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
              exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
              dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
              Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
              mollit anim id est laborum. Terit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
              officia deserunt mollit anim id est laborum. Herit in voluptate velit esse cillum
              dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt
              in culpa qui officia deserunt mollit anim id est laborum”
            </p>
            <h4>Interpretación</h4>
            <div class="muestra">
              <multiselect
                class="select-input-interp"
                v-model="selectedOptions"
                :options="options5"
                multiple
                label="text"
                track-by="value"
                placeholder="Escribe o Selecciona las opciones..."
                @select="onSelect"
              >
              </multiselect>
            </div>
            <p class="caja-txt">
              “Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
              incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
              exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
              dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
              Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
              mollit anim id est laborum. R proident, sunt in culpa qui officia deserunt mollit anim
              id est laborum. Terit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
              Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
              mollit anim id est laborum. Herit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
              officia deserunt mollit anim id est laborum”
            </p>
          </div>
          <div class="btn-consul-edita">
            <div class="btn-consulta">
              <button class="btn-consultar">Buscar</button>
            </div>
            <div class="btn-edita">
              <button class="btn-editar">Editar</button>
            </div>
          </div>
        </div>
        <div class="profesor-imag-V">
          <div class="profesor">
            <p class="prof">Profesor:</p>
            <input type="text" class="txtProfesor-input" />
          </div>

          <div class="imagenes-de-la-muestra-V">
            <div class="imagenes-de-la-muestra">
              <h4>Imágenes de la muestra</h4>
            </div>
            <div class="container">
              <div class="image-container" v-for="(image, index) in images" :key="index">
                <img :src="image.src" :alt="image.alt" />
                <p>{{ image.description }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import Multiselect from 'vue-multiselect'

export default defineComponent({
  name: 'ConsultaAnatomiaP',
  components: { Multiselect },
  props: {
    msg: String
  },
  setup() {
    const showSubmenu = ref(false)
    const selectedOption1 = ref(null)
    const selectedOption2 = ref(null)
    const selectedOption3 = ref(null)
    const selectedOption4 = ref('Calidad')
    const selectedOption5 = ref('Interpretación')
    const selectedOption6 = ref(null)
    const showDatePicker = ref(false)
    const selectedDate = ref(null)
    const selectedEstadoInforme = ref('string')
    const getColor = (value: string) => {
      if (value === null) {
        return 'black'
      }
      switch (value) {
        case '1':
          return 'red'
        case '2':
          return 'green'
        case '3':
          return 'blue'
        // Agrega más casos según sea necesario
        default:
          return 'black'
      }
    }
    const images = ref([
      { src: '/x4.jpeg', alt: 'Descripción de la imagen 1', description: 'x4' },
      { src: '/x10.png', alt: 'Descripción de la imagen 2', description: 'x10' },
      { src: '/x40.png', alt: 'Descripción de la imagen 3', description: 'x40' },
      { src: '/x100.png', alt: 'Descripción de la imagen 4', description: 'x100' },
      { src: '/x4.jpeg', alt: 'Descripción de la imagen 1', description: 'x4' },
      { src: '/x10.png', alt: 'Descripción de la imagen 2', description: 'x10' },
      { src: '/x40.png', alt: 'Descripción de la imagen 3', description: 'x40' },
      { src: '/x100.png', alt: 'Descripción de la imagen 4', description: 'x100' }
      // Agrega más objetos para más imágenes
    ])

    const optionsNaturaleza = ref([
      { text: '', value: '0' },
      { text: 'Biopsias', value: '1' },
      { text: 'Biopsias veterinarias', value: '2' },
      { text: 'Cavidad bucal', value: '3' },
      { text: 'Citología vaginal', value: '4' },
      { text: 'Extensión sanguínea', value: '5' },
      { text: 'Orinas', value: '6' },
      { text: 'Esputos', value: '7' },
      { text: 'Semen', value: '8' },
      { text: 'Improntas', value: '9' },
      { text: 'Frotis', value: '10' }
    ])
    const tipoOrgano = ref([
      { text: 'Corazón', value: '1' },
      { text: 'Hígado', value: '2' },
      { text: 'Riñón', value: '3' },
      { text: 'Pancreas', value: '4' }
    ])
    const optionsConservacion = ref([
      { text: '', value: '0' },
      { text: 'Formol', value: '1' },
      { text: 'Fresco', value: '2' },
      { text: 'Etanol 70%', value: '3' }
    ])

    const optionsEstadoInforme = ref([
      { text: '', value: '0' },
      { text: 'Pendiente de revisar', value: '1' },
      { text: 'Revisado OK', value: '2' },
      { text: 'Revisado con errores', value: '3' }
    ])

    const options4 = ref([
      { text: 'C.1. -Toma válida para examen.', value: '1' },
      {
        text: 'C.2. -Toma válida para examen aunque limitada por ausencia de células endocervicales / zona de transición',
        value: '2'
      },
      { text: 'C.3. -Toma válida para examen aunque limitada por hemorragia.', value: '3' },
      { text: 'C.4. -Toma válida para examen aunque limitada por escasez de células', value: '4' },
      { text: 'C.5. -Toma válida para examen aunque limitada por intensa citolisis', value: '5' },
      { text: 'C.6. -Toma válida para examen aunque limitada por...', value: '6' },
      { text: 'C.7. -Toma no valorable por desecación.', value: '7' },
      { text: 'C.8. -Toma no valorable por ausencia de células.', value: '8' },
      { text: 'C.9. -Toma no valorable', value: '9' }
    ])
    const options5 = ref([
      { text: '1.1. - Predominio de células epiteliales escamosas superficiales.', value: '1' },
      { text: '1.2. - Predominio de células epiteliales escamosas intermedias', value: '2' },
      { text: '1.3. - Predominio de células epiteliales escamosas parabasales', value: '3' },
      { text: '1.4. - Polinucleares neutrófilos.', value: '4' },
      { text: '1.5. - Hematíes.', value: '5' },
      { text: '1.6. - Células endocervicales en exocervix.', value: '6' },
      { text: '1.7. - Células metaplásicas en exocervix.', value: '7' },
      { text: '1.8. - Células metaplásicas inmaduras.', value: '8' },
      { text: '1.9. - Células reactivas.', value: '9' },
      { text: '1.10. - Células endometriales en mujer >= 40 años.', value: '10' },
      { text: '1.11. - Alteraciones celulares sugerentes con HPV.', value: '11' },
      { text: '1.12. - Aleraciones celulares sugerentes de Herpes.', value: '12' },
      { text: '1.13. - Células neoplásicas.', value: '13' },
      { text: '1.14. - Células superficiales e intermedias con cambios atípicos.', value: '14' },
      {
        text: '1.15. - Células intermedias y parabasales con algunos cambios atípicos.',
        value: '15'
      },
      { text: '1.16. - Células parabasales con algunos cambios atípicos.', value: '16' },
      { text: '1.17. - Células escamosas de significado incierto.', value: '17' },
      { text: '1.18. - Células epiteliales glandulares de significado incierto.', value: '18' },
      { text: '1.19. - Estructuras micóticas correspondientes a Candida albicans.', value: '19' },
      { text: '1.20. - Estructuras micóticas correspondientes a Candida glabrata.', value: '20' },
      {
        text: '1.21. - Estructuras bacterianas con disposición caracteristica de actimomycos.',
        value: '21'
      },
      {
        text: '1.22. - Estructuras bacterianas correspondiente de Gardmorella vaginalis.',
        value: '22'
      },
      { text: '1.23. - EStructuras bacterianas de naturaleza cocácea.', value: '23' },
      { text: '1.24. - Estructuras bacterianas sugerentes de Leptothrix.', value: '24' },
      { text: '1.25. - Estructuras corresponideintes a Trichomonas vaginalis.', value: '25' },
      { text: '1.26. - Células histiocitarias multinucleadas.', value: '26' },
      { text: '1.27. - Células histiocitarias multinucleadas.', value: '27' },
      { text: '1.28. - Presencia de epitelio endometrial sin cambios atípicos.', value: '28' },
      {
        text: '1.29. - Células epiteliales de apariencia glandular con núcleos amplios e irregulares.',
        value: '29'
      },
      { text: '2.1. - Predominio de eritrocitos normocíticos normocrómicos.', value: '1' },
      { text: '2.2. - Predominio de eritrocitos microcíticos hipocrómicos.', value: '2' },
      { text: '2.3. - Presencia de esferocitos.', value: '3' },
      { text: '2.4. - Presencia de dianocitos (células en forma de lágrima).', value: '4' },
      { text: '2.5. - Leucocitos con predominio de neutrófilos', value: '5' },
      { text: '2.6. - Leucocitos con predominio de linfocitos.', value: '6' },
      { text: '2.7. - Presencia de células blásticas.', value: '7' },
      { text: '2.8. - Presencia de eosinófilos aumentados.', value: '8' },
      { text: '2.9. - Presencia de basófilos aumentados.', value: '9' },
      { text: '2.10. - Trombocitosis (aumento de plaquetas).', value: '10' },
      { text: '2.11. - Trombocitopenia (disminución de plaquetas).', value: '11' },
      { text: '2.12. - Anomalías en la morfología plaquetaria.', value: '12' },
      { text: '2.13. - Presencia de células atípicas sugestivas de neoplasia', value: '13' },
      { text: '2.14. - Presencia de células inmaduras del linaje mieloide.', value: '14' },
      {
        text: '2.15. - Presencia de células inmaduras del linaje linfático.',
        value: '15'
      },
      { text: '2.16. - Anisocitosis (variabilidad en el tamaño de los eritrocitos)', value: '16' },
      {
        text: '2.17. - Poiquilocitosis (variabilidad en la forma de los eritrocitos).',
        value: '17'
      },
      { text: '2.18. - Presencia de cuerpos de Howell-Jolly', value: '18' },
      { text: '2.19. - Células con inclusiones de hierro (cuerpos de Pappenheimer).', value: '19' },
      { text: '2.20. - Presencia de parásitos intraeritrocitarios.', value: '20' },
      { text: '3.1. - pH normal.', value: '21' },
      { text: '3.2. - pH elevado.', value: '22' },
      { text: '3.3. - pH reducido.', value: '23' },
      { text: '3.4. - Presencia de proteínas.', value: '24' },
      { text: '3.5. - Negativo para proteínas.', value: '25' },
      { text: '3.6. - Glucosa presente.', value: '26' },
      { text: '3.7. - Negativo para la glucosa.', value: '27' },
      { text: '3.8. - Cetonas detectadas.', value: '28' },
      { text: '3.9. - Negativo para cetonas.', value: '29' },
      { text: '3.10.- Hemoglobina presente.', value: '30' },
      { text: '3.11.- Negativo para hemoglobina.', value: '' },
      { text: '3.12.- Bilirrubina detectada.', value: '31' },
      { text: '3.13.- Negativo para bilirrubina.', value: '32' },
      { text: '3.14.- Urobilinógeno normal.', value: '33' },
      { text: '3.15.- Urobilinógeno elevado.', value: '34' },
      { text: '3.16.- Presencia de nitritos.', value: '35' },
      { text: '3.17.- Negativo para nitritos.', value: '36' },
      { text: '3.18.- Presencia de leucocitos.', value: '37' },
      { text: '3.19.- Ausencia de leucocitos.', value: '38' },
      { text: '3.20.- Presencia de eritrocitos.', value: '39' },
      { text: '3.21.- Ausencia de eritrocitos.', value: '40' },
      { text: '3.22.- Células epiteliales.', value: '41' },
      { text: '3.23.- Cilindros hialinos.', value: '42' },
      { text: '3.24.- Cilindros granulosos.', value: '43' },
      { text: '3.25.- Cristales (oxalato de calcio, ácido úrico, etc.).', value: '44' },
      { text: '3.26.- Bacterias.', value: '45' },
      { text: '3.27.- Levaduras.', value: '46' },
      { text: '3.28.- Parásitos.', value: '47' },
      { text: '4.1. - Presencia de células epiteliales escamosas.', value: '48' },
      { text: '4.2. - Presencia de células epiteliales columnares.', value: '49' },
      {
        text: '4.3. - Presencia de células inflamatorias (neutrófilos, linfocitos, eosinófilos, macrófagos).',
        value: '50'
      },
      { text: '4.4. - Presencia de células metaplásicas.', value: '51' },
      { text: '4.5. - Presencia de células malignas.', value: '52' },
      { text: '4.6. - Presencia de células atípicas sugestivas de neoplasia.', value: '53' },
      {
        text: '4.7. - Presencia de microorganismos (bacterias, hongos, micobacterias).',
        value: '54'
      },
      { text: '4.8. - Presencia de células sanguíneas (eritrocitos, plaquetas).', value: '55' },
      { text: '4.9. - Presencia de material mucoso o mucopurulento.', value: '56' },
      { text: '4.10. - Presencia de cristales (de colesterol, calcio, etc.).', value: '57' },
      { text: '4.11. - Ausencia de células significativas para el análisis.', value: '58' },
      { text: '5.1. - Presencia de células epiteliales escamosas.', value: '59' },
      { text: '5.2. - Presencia de células epiteliales cilíndricas.', value: '60' },
      {
        text: '5.3. - Presencia de células inflamatorias (neutrófilos, linfocitos, macrófagos).',
        value: '61'
      },
      { text: '5.4. - Presencia de células glandulares.', value: '62' },
      { text: '5.5. - Presencia de células metaplásicas.', value: '63' },
      { text: '5.6. - Presencia de células atípicas sugestivas de neoplasia.', value: '64' },
      { text: '5.7. - Presencia de microorganismos (bacterias, hongos, levaduras).', value: '65' },
      { text: '5.8. - Presencia de células anormales con cambios citológicos.', value: '66' },
      { text: '5.9. - Ausencia de células significativas para el análisis.', value: '67' }
    ])

    const options = ref([
      { text: '2.1. - Predominio de eritrocitos normocíticos normocrómicos.', value: '1' },
      { text: '2.2. - Predominio de eritrocitos microcíticos hipocrómicos.', value: '2' },
      { text: '2.3. - Presencia de esferocitos.', value: '3' },
      { text: '2.4. - Presencia de dianocitos (células en forma de lágrima).', value: '4' },
      { text: '2.5. - Leucocitos con predominio de neutrófilos', value: '5' },
      { text: '2.6. - Leucocitos con predominio de linfocitos.', value: '6' },
      { text: '2.7. - Presencia de células blásticas.', value: '7' },
      { text: '2.8. - Presencia de eosinófilos aumentados.', value: '8' },
      { text: '2.9. - Presencia de basófilos aumentados.', value: '9' },
      { text: '2.10. - Trombocitosis (aumento de plaquetas).', value: '10' },
      { text: '2.11. - Trombocitopenia (disminución de plaquetas).', value: '11' },
      { text: '2.12. - Anomalías en la morfología plaquetaria.', value: '12' },
      { text: '2.13. - Presencia de células atípicas sugestivas de neoplasia', value: '13' },
      { text: '2.14. - Presencia de células inmaduras del linaje mieloide.', value: '14' },
      {
        text: '2.15. - Presencia de células inmaduras del linaje linfático.',
        value: '15'
      },
      { text: '2.16. - Anisocitosis (variabilidad en el tamaño de los eritrocitos)', value: '16' },
      {
        text: '2.17. - Poiquilocitosis (variabilidad en la forma de los eritrocitos).',
        value: '17'
      },
      { text: '2.18. - Presencia de cuerpos de Howell-Jolly', value: '18' },
      { text: '2.19. - Células con inclusiones de hierro (cuerpos de Pappenheimer).', value: '19' },
      { text: '2.20. - Presencia de parásitos intraeritrocitarios.', value: '20' }
    ])

    const tipoEstudio = ref([
      { text: '', value: '0' },
      { text: 'Citológico cérvico-vaginal.', value: '1' },
      { text: 'Hematológico completo', value: '2' },
      { text: 'Microscópico y químico de orina', value: '3' },
      { text: 'Citológico de esputo', value: '4' },
      { text: 'Citológico bucal', value: '5' }
    ])

    const selectedOptions = ref([{ text: '->', value: '0' }])

    const onSelect = () => {
      selectedOptions.value = selectedOptions.value.map((option) => {
        return { ...option, text: option.text.substring(0, 4) + ' ' }
      })
    }

    return {
      images,
      options,
      selectedOptions,
      onSelect,
      showSubmenu,
      selectedOption1,
      selectedOption2,
      selectedOption3,
      selectedOption4,
      selectedOption5,
      selectedOption6,
      showDatePicker,
      selectedDate,
      optionsNaturaleza,
      tipoOrgano,
      optionsConservacion,
      options4,
      options5,
      tipoEstudio,
      selectedEstadoInforme,
      optionsEstadoInforme,
      getColor
    }
  }
})
</script>
