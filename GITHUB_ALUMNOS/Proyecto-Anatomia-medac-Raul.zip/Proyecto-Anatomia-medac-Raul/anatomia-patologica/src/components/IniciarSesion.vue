<template>
  <div class="main-container">
    <div class="tt-cabecera">
      <p class="texto-tt-cabecera">Anatomía Patológica</p>
    </div>

    <div class="tt-imagen">
      <p class="texto-tt-imagen">INICIAR SESIÓN</p>
    </div>
  </div>
</template>
