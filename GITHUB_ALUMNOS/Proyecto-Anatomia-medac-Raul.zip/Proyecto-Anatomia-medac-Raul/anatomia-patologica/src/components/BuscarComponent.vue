<template>
  <div class="consultas-container">
    <div class="tt-cabecera"></div>
    <div class="tt-imagen-consultas">
      <p class="texto-tt-consultas">CONSULTAR INFORMES</p>
    </div>
    <div class="conten-gris">
      <div class="contenedor-txt-anadir">
        <div class="consulta-estado-informe">
          <div class="tt-estado-informe">
            <h2>Estado del Informe</h2>
          </div>
          <div class="estado-informe">
            <h4>Estado del informe:</h4>
            <select
              class="select-input"
              v-model="selectedEstadoInforme"
              :style="{ color: getColor(selectedEstadoInforme) }"
            >
              <option
                v-for="option3 in optionsEstadoInforme"
                :key="option3.value"
                :value="option3.value"
              >
                {{ option3.text }}
              </option>
            </select>
          </div>
        </div>
      </div>

      <div class="contenedor-txt-editar">
        <div class="cod-fecha-user">
          <div class="codigo">
            <p>Código:</p>
            <input type="text" class="textfield-input" />
          </div>
          <div class="fecha">
            <p>Fecha:</p>
          </div>
          <div class="calendar">
            <input type="date" class="date-input" v-model="selectedDate" onkeydown="return false" />
          </div>
          <div class="usuario">
            <p>Usuario:</p>
            <input type="text" class="txtUsuario-input" />
          </div>
        </div>

        <div class="img-placa"></div>
      </div>
      <div class="contenedor-txt-consulta">
        <div class="consultar-muestra">
          <div class="editar-muestra">
            <div class="muestra">
              <h4>Naturaleza de la muestra</h4>
              <select class="select-input" v-model="selectedOption1">
                <option
                  v-for="option1 in optionsNaturaleza"
                  :key="option1.value"
                  :value="option1.value"
                  v-bind:style="{
                    'font-weight':
                      option1.value === '1' || option1.value === '2' ? 'bold' : 'normal',
                    color: option1.value === '1' || option1.value === '2' ? '#004676' : '#004676'
                  }"
                >
                  {{ option1.text }}
                </option>
              </select>
            </div>

            <div class="tipo-muestra">
              <h4>Tipo de estudio</h4>
              <select class="select-input" v-model="selectedOption6">
                <option v-for="option6 in tipoEstudio" :key="option6.value" :value="option6.value">
                  {{ option6.text }}
                </option>
              </select>
            </div>

            <div class="muestra">
              <h4>Conservación de la Muestra</h4>
              <select class="select-input" v-model="selectedOption3">
                <option
                  v-for="option3 in optionsConservacion"
                  :key="option3.value"
                  :value="option3.value"
                >
                  {{ option3.text }}
                </option>
              </select>
            </div>
          </div>
          <div class="tipo-muestra-tt-descrip">
            <div class="muestra">
              <div class="tip-org" v-if="selectedOption1 === '1' || selectedOption1 === '2'">
                <h4>Tipo de Órgano</h4>
              </div>
              <select
                class="cmb-TipoOrgano"
                v-model="selectedOption2"
                v-if="selectedOption1 === '1' || selectedOption1 === '2'"
              >
                <option v-for="option2 in tipoOrgano" :key="option2.value" :value="option2.value">
                  {{ option2.text }}
                </option>
              </select>
            </div>
          </div>
          <div class="texto-descrip">
            <h3>Descripción citológica o tisular de la muestra</h3>
          </div>
          <div class="editar-muestra-vert">
            <div class="muestra-calidad">
              <h4>Calidad</h4>
              <select class="select-input-calidad" v-model="selectedOption4">
                <option v-for="option4 in options4" :key="option4.value" :value="option4.value">
                  {{ option4.text }}
                </option>
              </select>
            </div>
            <p class="caja-txt">
              “Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
              incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
              exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
              dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
              Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
              mollit anim id est laborum. Terit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
              officia deserunt mollit anim id est laborum. Herit in voluptate velit esse cillum
              dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt
              in culpa qui officia deserunt mollit anim id est laborum”
            </p>
            <h4>Interpretación</h4>
            <div class="muestra">
              <multiselect
                class="select-input-interp"
                v-model="selectedOptions"
                :options="options5"
                multiple
                label="text"
                track-by="value"
                placeholder="Escribe o Selecciona las opciones..."
                @select="onSelect"
              >
              </multiselect>
            </div>
            <p class="caja-txt">
              “Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
              incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
              exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
              dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
              Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
              mollit anim id est laborum. R proident, sunt in culpa qui officia deserunt mollit anim
              id est laborum. Terit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
              Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
              mollit anim id est laborum. Herit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
              officia deserunt mollit anim id est laborum”
            </p>
          </div>
          <div class="btn-consul-edita">
            <div class="btn-consulta">
              <button class="btn-consultar">Buscar</button>
            </div>
            <div class="btn-edita">
              <button class="btn-editar">Editar</button>
            </div>
          </div>
        </div>
        <div class="profesor-imag-V">
          <div class="profesor">
            <p class="prof">Profesor:</p>
            <input type="text" class="txtProfesor-input" />
          </div>

          <div class="imagenes-de-la-muestra-V">
            <div class="imagenes-de-la-muestra">
              <h4>Imágenes de la muestra</h4>
            </div>
            <div class="container">
              <div class="image-container" v-for="(image, index) in images" :key="index">
                <img :src="image.src" :alt="image.alt" />
                <p>{{ image.description }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import Multiselect from 'vue-multiselect'

export default defineComponent({
  name: 'ConsultaAnatomiaP',
  components: { Multiselect },
  props: {
    msg: String
  },
  setup() {
    const showSubmenu = ref(false)
    const selectedOption1 = ref(null)
    const selectedOption2 = ref(null)
    const selectedOption3 = ref(null)
    const selectedOption4 = ref('Calidad')
    const selectedOption5 = ref('Interpretación')
    const selectedOption6 = ref(null)
    const showDatePicker = ref(false)
    const selectedDate = ref(null)
    const selectedEstadoInforme = ref('string')
    const getColor = (value: string) => {
      if (value === null) {
        return 'black'
      }
      switch (value) {
        case '1':
          return 'red'
        case '2':
          return 'green'
        case '3':
          return 'blue'
        // Agrega más casos según sea necesario
        default:
          return 'black'
      }
    }
    const images = ref([
      { src: '/x4.jpeg', alt: 'Descripción de la imagen 1', description: 'x4' },
      { src: '/x10.png', alt: 'Descripción de la imagen 2', description: 'x10' },
      { src: '/x40.png', alt: 'Descripción de la imagen 3', description: 'x40' },
      { src: '/x100.png', alt: 'Descripción de la imagen 4', description: 'x100' },
      { src: '/x4.jpeg', alt: 'Descripción de la imagen 1', description: 'x4' },
      { src: '/x10.png', alt: 'Descripción de la imagen 2', description: 'x10' },
      { src: '/x40.png', alt: 'Descripción de la imagen 3', description: 'x40' },
      { src: '/x100.png', alt: 'Descripción de la imagen 4', description: 'x100' }
      // Agrega más objetos para más imágenes
    ])

    const optionsNaturaleza = ref([
      { text: 'Tipo', value: '0' },
      { text: 'Biopsiass', value: '1' },
      { text: 'Biopsias veterinarias', value: '2' },
      { text: 'Cavidad bucal', value: '3' },
      { text: 'Citología vaginal', value: '4' },
      { text: 'Extensión sanguínea', value: '5' },
      { text: 'Orinas', value: '6' },
      { text: 'Esputos', value: '7' },
      { text: 'Semen', value: '8' },
      { text: 'Improntas', value: '9' },
      { text: 'Frotis', value: '10' }
    ])
    const tipoOrgano = ref([
      { text: 'Corazón', value: '1' },
      { text: 'Hígado', value: '2' },
      { text: 'Riñón', value: '3' },
      { text: 'Pancreas', value: '4' }
    ])
    const optionsConservacion = ref([
      { text: '', value: '0' },
      { text: 'Formol', value: '1' },
      { text: 'Fresco', value: '2' },
      { text: 'Etanol 70%', value: '3' }
    ])

    const optionsEstadoInforme = ref([
      { text: '', value: '0' },
      { text: 'Pendiente de revisar', value: '1' },
      { text: 'Revisado OK', value: '2' },
      { text: 'Revisado con errores', value: '3' }
    ])

    const options4 = ref([
      { text: 'C.1. -Toma válida para examen.', value: '1' },
      {
        text: 'C.2. -Toma válida para examen aunque limitada por ausencia de células endocervicales / zona de transición',
        value: '2'
      },
      { text: 'C.3. -Toma válida para examen aunque limitada por hemorragia.', value: '3' },
      { text: 'C.4. -Toma válida para examen aunque limitada por escasez de células', value: '4' },
      { text: 'C.5. -Toma válida para examen aunque limitada por intensa citolisis', value: '5' },
      { text: 'C.6. -Toma válida para examen aunque limitada por...', value: '6' },
      { text: 'C.7. -Toma no valorable por desecación.', value: '7' },
      { text: 'C.8. -Toma no valorable por ausencia de células.', value: '8' },
      { text: 'C.9. -Toma no valorable', value: '9' }
    ])
    const options5 = ref([
      { text: '1.1. - Predominio de células epiteliales escamosas superficiales.', value: '1' },
      { text: '1.2. - Predominio de células epiteliales escamosas intermedias', value: '2' },
      { text: '1.3. - Predominio de células epiteliales escamosas parabasales', value: '3' },
      { text: '1.4. - Polinucleares neutrófilos.', value: '4' },
      { text: '1.5. - Hematíes.', value: '5' },
      { text: '1.6. - Células endocervicales en exocervix.', value: '6' },
      { text: '1.7. - Células metaplásicas en exocervix.', value: '7' },
      { text: '1.8. - Células metaplásicas inmaduras.', value: '8' },
      { text: '1.9. - Células reactivas.', value: '9' },
      { text: '1.10. - Células endometriales en mujer >= 40 años.', value: '10' },
      { text: '1.11. - Alteraciones celulares sugerentes con HPV.', value: '11' },
      { text: '1.12. - Aleraciones celulares sugerentes de Herpes.', value: '12' },
      { text: '1.13. - Células neoplásicas.', value: '13' },
      { text: '1.14. - Células superficiales e intermedias con cambios atípicos.', value: '14' },
      {
        text: '1.15. - Células intermedias y parabasales con algunos cambios atípicos.',
        value: '15'
      },
      { text: '1.16. - Células parabasales con algunos cambios atípicos.', value: '16' },
      { text: '1.17. - Células escamosas de significado incierto.', value: '17' },
      { text: '1.18. - Células epiteliales glandulares de significado incierto.', value: '18' },
      { text: '1.19. - Estructuras micóticas correspondientes a Candida albicans.', value: '19' },
      { text: '1.20. - Estructuras micóticas correspondientes a Candida glabrata.', value: '20' },
      {
        text: '1.21. - Estructuras bacterianas con disposición caracteristica de actimomycos.',
        value: '21'
      },
      {
        text: '1.22. - Estructuras bacterianas correspondiente de Gardmorella vaginalis.',
        value: '22'
      },
      { text: '1.23. - EStructuras bacterianas de naturaleza cocácea.', value: '23' },
      { text: '1.24. - Estructuras bacterianas sugerentes de Leptothrix.', value: '24' },
      { text: '1.25. - Estructuras corresponideintes a Trichomonas vaginalis.', value: '25' },
      { text: '1.26. - Células histiocitarias multinucleadas.', value: '26' },
      { text: '1.27. - Células histiocitarias multinucleadas.', value: '27' },
      { text: '1.28. - Presencia de epitelio endometrial sin cambios atípicos.', value: '28' },
      {
        text: '1.29. - Células epiteliales de apariencia glandular con núcleos amplios e irregulares.',
        value: '29'
      },
      { text: '2.1. - Predominio de eritrocitos normocíticos normocrómicos.', value: '1' },
      { text: '2.2. - Predominio de eritrocitos microcíticos hipocrómicos.', value: '2' },
      { text: '2.3. - Presencia de esferocitos.', value: '3' },
      { text: '2.4. - Presencia de dianocitos (células en forma de lágrima).', value: '4' },
      { text: '2.5. - Leucocitos con predominio de neutrófilos', value: '5' },
      { text: '2.6. - Leucocitos con predominio de linfocitos.', value: '6' },
      { text: '2.7. - Presencia de células blásticas.', value: '7' },
      { text: '2.8. - Presencia de eosinófilos aumentados.', value: '8' },
      { text: '2.9. - Presencia de basófilos aumentados.', value: '9' },
      { text: '2.10. - Trombocitosis (aumento de plaquetas).', value: '10' },
      { text: '2.11. - Trombocitopenia (disminución de plaquetas).', value: '11' },
      { text: '2.12. - Anomalías en la morfología plaquetaria.', value: '12' },
      { text: '2.13. - Presencia de células atípicas sugestivas de neoplasia', value: '13' },
      { text: '2.14. - Presencia de células inmaduras del linaje mieloide.', value: '14' },
      {
        text: '2.15. - Presencia de células inmaduras del linaje linfático.',
        value: '15'
      },
      { text: '2.16. - Anisocitosis (variabilidad en el tamaño de los eritrocitos)', value: '16' },
      {
        text: '2.17. - Poiquilocitosis (variabilidad en la forma de los eritrocitos).',
        value: '17'
      },
      { text: '2.18. - Presencia de cuerpos de Howell-Jolly', value: '18' },
      { text: '2.19. - Células con inclusiones de hierro (cuerpos de Pappenheimer).', value: '19' },
      { text: '2.20. - Presencia de parásitos intraeritrocitarios.', value: '20' },
      { text: '3.1. - pH normal.', value: '21' },
      { text: '3.2. - pH elevado.', value: '22' },
      { text: '3.3. - pH reducido.', value: '23' },
      { text: '3.4. - Presencia de proteínas.', value: '24' },
      { text: '3.5. - Negativo para proteínas.', value: '25' },
      { text: '3.6. - Glucosa presente.', value: '26' },
      { text: '3.7. - Negativo para la glucosa.', value: '27' },
      { text: '3.8. - Cetonas detectadas.', value: '28' },
      { text: '3.9. - Negativo para cetonas.', value: '29' },
      { text: '3.10.- Hemoglobina presente.', value: '30' },
      { text: '3.11.- Negativo para hemoglobina.', value: '' },
      { text: '3.12.- Bilirrubina detectada.', value: '31' },
      { text: '3.13.- Negativo para bilirrubina.', value: '32' },
      { text: '3.14.- Urobilinógeno normal.', value: '33' },
      { text: '3.15.- Urobilinógeno elevado.', value: '34' },
      { text: '3.16.- Presencia de nitritos.', value: '35' },
      { text: '3.17.- Negativo para nitritos.', value: '36' },
      { text: '3.18.- Presencia de leucocitos.', value: '37' },
      { text: '3.19.- Ausencia de leucocitos.', value: '38' },
      { text: '3.20.- Presencia de eritrocitos.', value: '39' },
      { text: '3.21.- Ausencia de eritrocitos.', value: '40' },
      { text: '3.22.- Células epiteliales.', value: '41' },
      { text: '3.23.- Cilindros hialinos.', value: '42' },
      { text: '3.24.- Cilindros granulosos.', value: '43' },
      { text: '3.25.- Cristales (oxalato de calcio, ácido úrico, etc.).', value: '44' },
      { text: '3.26.- Bacterias.', value: '45' },
      { text: '3.27.- Levaduras.', value: '46' },
      { text: '3.28.- Parásitos.', value: '47' },
      { text: '4.1. - Presencia de células epiteliales escamosas.', value: '48' },
      { text: '4.2. - Presencia de células epiteliales columnares.', value: '49' },
      {
        text: '4.3. - Presencia de células inflamatorias (neutrófilos, linfocitos, eosinófilos, macrófagos).',
        value: '50'
      },
      { text: '4.4. - Presencia de células metaplásicas.', value: '51' },
      { text: '4.5. - Presencia de células malignas.', value: '52' },
      { text: '4.6. - Presencia de células atípicas sugestivas de neoplasia.', value: '53' },
      {
        text: '4.7. - Presencia de microorganismos (bacterias, hongos, micobacterias).',
        value: '54'
      },
      { text: '4.8. - Presencia de células sanguíneas (eritrocitos, plaquetas).', value: '55' },
      { text: '4.9. - Presencia de material mucoso o mucopurulento.', value: '56' },
      { text: '4.10. - Presencia de cristales (de colesterol, calcio, etc.).', value: '57' },
      { text: '4.11. - Ausencia de células significativas para el análisis.', value: '58' },
      { text: '5.1. - Presencia de células epiteliales escamosas.', value: '59' },
      { text: '5.2. - Presencia de células epiteliales cilíndricas.', value: '60' },
      {
        text: '5.3. - Presencia de células inflamatorias (neutrófilos, linfocitos, macrófagos).',
        value: '61'
      },
      { text: '5.4. - Presencia de células glandulares.', value: '62' },
      { text: '5.5. - Presencia de células metaplásicas.', value: '63' },
      { text: '5.6. - Presencia de células atípicas sugestivas de neoplasia.', value: '64' },
      { text: '5.7. - Presencia de microorganismos (bacterias, hongos, levaduras).', value: '65' },
      { text: '5.8. - Presencia de células anormales con cambios citológicos.', value: '66' },
      { text: '5.9. - Ausencia de células significativas para el análisis.', value: '67' }
    ])

    const options = ref([
      { text: '2.1. - Predominio de eritrocitos normocíticos normocrómicos.', value: '1' },
      { text: '2.2. - Predominio de eritrocitos microcíticos hipocrómicos.', value: '2' },
      { text: '2.3. - Presencia de esferocitos.', value: '3' },
      { text: '2.4. - Presencia de dianocitos (células en forma de lágrima).', value: '4' },
      { text: '2.5. - Leucocitos con predominio de neutrófilos', value: '5' },
      { text: '2.6. - Leucocitos con predominio de linfocitos.', value: '6' },
      { text: '2.7. - Presencia de células blásticas.', value: '7' },
      { text: '2.8. - Presencia de eosinófilos aumentados.', value: '8' },
      { text: '2.9. - Presencia de basófilos aumentados.', value: '9' },
      { text: '2.10. - Trombocitosis (aumento de plaquetas).', value: '10' },
      { text: '2.11. - Trombocitopenia (disminución de plaquetas).', value: '11' },
      { text: '2.12. - Anomalías en la morfología plaquetaria.', value: '12' },
      { text: '2.13. - Presencia de células atípicas sugestivas de neoplasia', value: '13' },
      { text: '2.14. - Presencia de células inmaduras del linaje mieloide.', value: '14' },
      {
        text: '2.15. - Presencia de células inmaduras del linaje linfático.',
        value: '15'
      },
      { text: '2.16. - Anisocitosis (variabilidad en el tamaño de los eritrocitos)', value: '16' },
      {
        text: '2.17. - Poiquilocitosis (variabilidad en la forma de los eritrocitos).',
        value: '17'
      },
      { text: '2.18. - Presencia de cuerpos de Howell-Jolly', value: '18' },
      { text: '2.19. - Células con inclusiones de hierro (cuerpos de Pappenheimer).', value: '19' },
      { text: '2.20. - Presencia de parásitos intraeritrocitarios.', value: '20' }
    ])

    const tipoEstudio = ref([
      { text: '', value: '0' },
      { text: 'Citológico cérvico-vaginal.', value: '1' },
      { text: 'Hematológico completo', value: '2' },
      { text: 'Microscópico y químico de orina', value: '3' },
      { text: 'Citológico de esputo', value: '4' },
      { text: 'Citológico bucal', value: '5' }
    ])

    const selectedOptions = ref([{ text: '->', value: '0' }])

    const onSelect = () => {
      selectedOptions.value = selectedOptions.value.map((option) => {
        return { ...option, text: option.text.substring(0, 4) + ' ' }
      })
    }

    return {
      images,
      options,
      selectedOptions,
      onSelect,
      showSubmenu,
      selectedOption1,
      selectedOption2,
      selectedOption3,
      selectedOption4,
      selectedOption5,
      selectedOption6,
      showDatePicker,
      selectedDate,
      optionsNaturaleza,
      tipoOrgano,
      optionsConservacion,
      options4,
      options5,
      tipoEstudio,
      selectedEstadoInforme,
      optionsEstadoInforme,
      getColor
    }
  }
})
</script>

<style>
/* Con scoped los estilos solo se aplican al componente actual, sin scoped se aplican a toda la aplicación */
.consultas-container {
  width: 1440px;
  height: auto;
  border: 0px;
  overflow-y: auto; /* Agrega una barra de desplazamiento horizontal si es necesario */
  white-space-collapse: auto; /* Evita que las imágenes se envuelvan a la siguiente línea */
}

.tt-estado-informe {
  width: 245px;
  text-align: center;
  padding-left: 4px;
  border: 5px solid #dee5ed;
  background-color: #dee5ed;
  border-radius: 10px;
}

.conten-gris {
  height: 990px;
  border: 0px;
  padding-top: 10px;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  background-color: #f5f5f5;
  border-radius: 20px;
}

.consulta-estado-informe {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: left;
  margin-top: 0px;
  margin-left: 0px;
  margin-right: 0px;
  margin-bottom: 0px;
  padding: 16px;
  border: 10px solid #ffffff;
  border-radius: 20px;
  background-color: #ffffff;
  font-weight: bold;
}

.consultar-muestra {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: left;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  padding: 16px;
  border: 0px solid #004676;
}

.editar-muestra {
  display: flex;
  justify-content: space-between;
  flex-direction: row;
  width: 100%;
  align-items: left;
  margin-top: 0px;
  margin-left: 0px;
  margin-right: 20px;
  margin-bottom: 20px;
  padding: 10px;
}

.editar-muestra-vert {
  display: flex;
  flex-direction: column;
}

.cmb-TipoOrgano {
  width: 120px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  margin-top: 0px;
  margin-bottom: 0px;
}

.imagenes-de-la-muestra-V {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100%; /* Asegúrate de que el contenedor tenga una altura definida */
}
.imagenes-de-la-muestra {
  margin-left: -40px;
  margin-bottom: 16px;
}

.prof {
  margin-bottom: 0px;
  background-color: #ffffff;
  margin-left: 130px;
  margin-right: 20px;
  padding-right: 20px;
}
.profesor {
  display: flex;
  justify-content: space-between;
  margin-right: 24px;
  margin-top: -40px;
}

.txtProfesor-input {
  width: 200px;
  height: 26px;
  margin-right: 0px;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}

.muestra {
  display: flex;
  flex-direction: column;
  margin-bottom: 28px;
  background-color: #ffffff;
}

.muestra-calidad {
  display: flex;
  flex-direction: column;
  margin-top: -30px;
}

.tipo-muestra {
  display: flex;
  flex-direction: column;
  margin-bottom: 40px;
}

.tipo-muestra-tt-descrip {
  margin-top: -30px;
  margin-top: 100px;
  background-color: #ffffff;
  color: #004676;
  max-height: 30px;
  width: 300px;
  position: fixed;
}

.tip-org {
  margin-top: 0px;
  margin-bottom: 0px;
  background-color: #ffffff;
}

.texto-descrip {
  display: flex;
  margin-left: 160px;
  margin-bottom: 10px;
  margin-top: 10px;
}

.contenedor-txt-anadir {
  display: flex;
  justify-content: space-between;
  border: 20px solid #f5f5f5;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  border-bottom: 20px;
  margin-top: 0px;
  margin-left: 40px;
  margin-right: 40px;
  margin-bottom: 0px;
}

.contenedor-txt-editar {
  height: 60px;
  display: flex;
  justify-content: flex-start;
  margin-top: 20px;
  margin-left: 60px;
  margin-right: 60px;
  margin-bottom: 0px;
  background-color: #ffffff;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
}

.codigo {
  display: flex;
  margin-right: 5px;
  margin-left: 20px;
  margin-top: 20px;
  border-color: #004676;
}
.textfield-input {
  width: 150px;
  height: 26px;
  margin-left: 10px;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}
.textfield-input:focus {
  color: #004676;
  background-color: #ffffff;
}

.usuario {
  display: flex;
  margin-right: 5px;
  margin-left: 10px;
  margin-top: 20px;
  border-color: #004676;
}

.txtUsuario-input {
  width: 190px;
  height: 26px;
  margin-left: 10px;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}
.txtUsuario-input:focus {
  color: #004676;
  background-color: #ffffff;
}
.cod-fecha-user {
  display: flex;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  border-radius: 20px;
}

.fecha {
  display: flex;
  margin-right: 10px;
  margin-left: 20px;
  margin-top: 20px;
  border-color: #004676;
}

.calendar {
  display: flex;
  margin-right: 15px;
  margin-top: 26px;
  height: 20px;
}

.date-input {
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  height: 26px;
  margin-top: -6px;
  font-weight: bold;
}
.date-input:focus {
  color: #004676;
  background-color: #ffffff;
}
.select-input {
  width: 200px;
  height: 26px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}

.select-input:hover {
  background-color: #f5f5f5;
}

.select-input .option--highlight {
  background-color: #004676 !important;
  color: #ffffff !important;
}

.select-input-calidad {
  width: 760px;
  height: 20px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  font-size: 15px;
}

.select-input-calidad:hover {
  background-color: #f5f5f5;
}

.select-input-calidad .option--highlight {
  background-color: #004676 !important;
  color: #ffffff !important;
}

.select-input-interp {
  width: 670px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  max-height: 300px;
  overflow-y: auto;
  position: fixed;
  z-index: 1;
}

.select-input-interp .multiselect__input {
  font-size: 18px;
}

.select-input-interp .multiselect__content-wrapper {
  position: fixed;
  max-height: 300px;
  overflow-y: auto;
  width: 100%;
  z-index: 1;
}

.select-input-interp:hover {
  background-color: #f5f5f5;
}

.select-input-interp .multiselect__option--highlight {
  background-color: #004676 !important;
  color: #ffffff !important;
}

.select-input-interp .multiselect__content-wrapper {
  background-color: #ffffff;
  position: fixed;
  height: 158px;
  overflow-y: 50px;
  width: 670px;
  z-index: 1;
  border: solid 1px #004676;
}

.tt-descipcion {
  margin-top: -30px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  text-align: center;
  font-weight: bold;
}

.contenedor-txt-consulta {
  height: 750px;
  display: flex;
  justify-content: space-between;
  border-top: 0px solid #f5f5f5;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  margin-top: 0px;
  margin-left: 60px;
  margin-right: 60px;
  margin-bottom: 20px;
  background-color: #ffffff;
}

.caja-txt {
  width: 100%;
  height: 260px;
  margin-top: 20px;
  margin-bottom: 30px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  max-height: 156px;
  overflow-y: auto;
  scrollbar-color: #406985 #f1f1f1;
}

.imagen-placa,
.imagen-muestra,
.imagen-inicioP {
  border-radius: 40px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  padding: 16px;
  border: 0px;
}

h1 {
  font-weight: 500;
  font-size: 2.6rem;
  position: relative;
  top: -10px;
  text-align: left;
}

h2 {
  font-size: 22px;
  font-weight: bold;
  text-align: left;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: left;
}

.tt-imagen-consultas {
  max-width: 400px;
  background-color: #f5f5f5;
  text-align: center;
  margin: 0 auto;
  margin-top: 60px;
  padding: 10px;
  border: 1px solid #004676;
  border-bottom: 0px;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  font-weight: bold;
}

.texto-tt-consultas {
  font-weight: bold;
  color: #004676;
}

.btn-edita {
  display: flex;
  justify-content: center;
  margin-top: -20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
}

.btn-consulta {
  display: flex;
  justify-content: center;
  margin-top: -20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
}
.btn-consul-edita {
  display: flex;
  justify-content: space-between;
}

.btn-editar {
  width: 175px;
  height: 32px;
  background-color: #004676;
  color: #ffffff;
  border: 0px;
  border-radius: 6px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.6);
}

.btn-consultar {
  width: 175px;
  height: 32px;
  background-color: #004676;
  color: #ffffff;
  border: 0px;
  border-radius: 6px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.6);
}

.btn-consultar:hover {
  background-color: #165c8c; /* Cambia el color de fondo al pasar el cursor por encima */
}

.btn-consultar:active {
  background-color: #002244; /* Cambia el color de fondo al hacer clic */
}

.container {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: repeat(2, 1fr);
  gap: 10px; /* Ajusta el espacio entre las imágenes */
  height: 100%;
  width: 100%;
  overflow-y: scroll; /* Agrega la barra de desplazamiento vertical */
  border: 1px solid #004676;
  margin-top: 50px;
  margin-right: 10px;
  margin-left: -20px;
  margin-bottom: -30px;
  scrollbar-color: #004676;
}

.image-container img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  padding-top: 20px;
  padding-right: 10px;
  padding-left: 10px;
  margin-bottom: -10px;
}

.image-container p {
  text-align: center;
}

.imagen-inicio {
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
}

.container::-webkit-scrollbar {
  width: 12px; /* Ancho de la barra de desplazamiento */
  height: 100px;
}

.container::-webkit-scrollbar-track {
  background: #dee5ed; /* Color de la pista de la barra de desplazamiento */
}

.container::-webkit-scrollbar-thumb {
  background: #84a3b9; /* Color del pulgar de la barra de desplazamiento */
}

.container::-webkit-scrollbar-thumb:hover {
  background: #004676; /* Color del pulgar de la barra de desplazamiento al pasar el mouse */
}


.select-input-sede {
  width: 200px;
  height: 26px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}

.select-input-sede:hover {
  background-color: #f5f5f5;
}

.select-input-sede .option--highlight {
  background-color: #004676 !important;
  color: #ffffff !important;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
