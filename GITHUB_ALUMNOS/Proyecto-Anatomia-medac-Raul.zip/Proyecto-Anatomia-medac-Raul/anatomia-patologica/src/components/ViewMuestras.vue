<template>
  <div class="consultas-container">
    <div class="tt-cabecera"></div>
    <div class="tt-imagen-consultas">
      <p class="texto-tt-consultas">ENVIAR INFORMES</p>
    </div>
    <div class="conten-gris">
      <div class="contenedor-txt-anadir">
        <div class="consulta-estado-informe">
          <div class="tt-estado-informe">
            <h2>Insertar nuevo Informe</h2>
          </div>
          <div class="estado-informe">
            <h4>Estado del informe:</h4>
          </div>
        </div>
        <div class="contenedor-txt-editar">
          <!--container-form-muestras  no tiene caja-->
          <div class="contenedor-txt-consulta">
            <p>haoslsd</p>
            <form class="form-muestras" @submit.prevent="goToNextPart">
              <div style="display: flex; justify-content: space-between">
                <div>
                  <div>
                    <label for="code">Código de la muestra</label>
                    <input
                      class="input-muestras"
                      type="number"
                      v-model="code"
                      name="code"
                      placeholder="Código"
                    />
                  </div>
                  <div>
                    <label for="nature">Naturaleza de la muestra</label>
                    <div>
                      <select class="input-muestras" v-model="nature" required>
                        <option name="nature" value="" selected>Tipo</option>
                        <option name="nature" value="Biopsia">Biopsia</option>
                        <option name="nature" value="otra">Otra</option>
                        <option name="nature" value="Nobiopsy">Nobiopsy</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label for="conservation">Conservación de muestra</label>
                    <div>
                      <select class="input-muestras" v-model="conservation" required>
                        <option name="conservation" value="" selected>Formato</option>
                        <option name="conservation" value="Formol">Formol</option>
                        <option name="conservation" value="Otro">Otro</option>
                        <option name="conservation" value="Formol2">Formol2</option>
                        <option name="conservation" value="Noformol">Noformol</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div>
                  <div>
                    <label for="dateColected">Fecha de recolección</label>
                    <input
                      class="input-muestras"
                      type="date"
                      v-model="dateColected"
                      name="dateColected"
                    />
                  </div>
                  <div>
                    <label for="biopsy">Opciones biopsia</label>
                    <div>
                      <select class="input-muestras" v-model="biopsy" required>
                        <option name="biopsy" value="" selected>Órgano</option>
                        <option name="biopsy" value="Corazón">Corazón</option>
                        <option name="biopsy" value="pulmón">Pulmón</option>
                        <option name="biopsy" value="Albacete">otro</option>
                        <option name="biopsy" value="otro">Otro</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label for="sede">Centro de procedencia</label>
                    <div>
                      <select class="input-muestras" v-model="sede" required>
                        <option value="" selected>Sede</option>
                        <option value="Albacete">Albacete</option>
                        <option value="Alicante">Alicante</option>
                        <option value="Alicante II">Alicante II</option>
                        <option value="Almeria">Almería</option>
                        <option value="Cordoba">Córdoba</option>
                        <option value="Granada">Granada</option>
                        <option value="Huelva">Huelva</option>
                        <option value="Jerez">Jerez</option>
                        <option value="Madrid">Madrid</option>
                        <option value="Madrid II">Madrid II</option>
                        <option value="Malaga">Málaga</option>
                        <option value="Murcia">Murcia</option>
                        <option value="Sevilla">Sevilla</option>
                        <option value="Valencia">Valencia</option>
                        <option value="Zaragoza">Zaragoza</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div>
                  <div>
                    <label for="img">Imágenes de la muestra</label>
                    <input class="input-muestras" type="file" @change="onFileChange" multiple />
                    <img v-if="imgUrl" :src="imgUrl" alt="Vista previa de la imagen" />
                  </div>
                </div>
              </div>

              <button class="btn-muestras" type="submit">Siguiente</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
//import UserHeader from './HeaderUser.vue'
//import { useCounterStore } from '../stores/counter.js'

export default {
  components: {
    //  UserHeader
  },
  data() {
    return {
      code: '',
      nature: '',
      dateColected: '',
      conservation: '',
      biopsy: '',
      sede: '',
      imgUrls: []
    }
  },
  /*
  methods: {
    goToNextPart() {
      this.$router.push({
        name: 'ViewMuestras2',
        params: {
          code: this.code,
          nature: this.nature,
          dateColected: this.dateColected,
          conservation: this.conservation,
          biopsy: this.biopsy,
          sede: this.sede,
          imgUrls: JSON.stringify(this.imgUrls)
        }
      })
    },
    onFileChange(e) {
      const files = e.target.files
      const counterStore = useCounterStore()
      Array.from(files).forEach((file) => {
        const reader = new FileReader()
        reader.onload = (event) => {
          counterStore.addImage(event.target.result)
        }
        reader.readAsDataURL(file)
        this.imgUrls.push(file.name)
      })
      console.log(this.imgUrls)
    }
  },
  */
  name: 'ViewMuestras'
}
</script>

<!--
<style src="../assets/css/muestras.css"></style>
-->

<style>
.consultas-container {
  width: 1440px;
  height: auto;
  border: 0px;
  overflow-y: auto; /* Agrega una barra de desplazamiento horizontal si es necesario */
  white-space-collapse: auto; /* Evita que las imágenes se envuelvan a la siguiente línea */
}

.tt-estado-informe {
  width: 260px;
  text-align: center;
  padding-left: 4px;
  border: 5px solid #dee5ed;
  background-color: #dee5ed;
  border-radius: 10px;
}

.conten-gris {
  height: 990px;
  border: 0px;
  padding-top: 10px;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  background-color: #f5f5f5;
  border-radius: 20px;
}

.consulta-estado-informe {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: left;
  margin-top: 0px;
  margin-left: 0px;
  margin-right: 0px;
  margin-bottom: 0px;
  padding: 16px;
  border: 10px solid #ffffff;
  border-radius: 20px;
  background-color: #ffffff;
  font-weight: bold;
}

.consultar-muestra {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: left;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  padding: 16px;
  border: 0px solid #004676;
}

.editar-muestra {
  display: flex;
  justify-content: space-between;
  flex-direction: row;
  width: 100%;
  align-items: left;
  margin-top: 0px;
  margin-left: 0px;
  margin-right: 20px;
  margin-bottom: 20px;
  padding: 10px;
}

.editar-muestra-vert {
  display: flex;
  flex-direction: column;
}

.cmb-TipoOrgano {
  width: 120px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  margin-top: 0px;
  margin-bottom: 0px;
}

.profesor-imag-V {
  width: 700px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  margin-top: 0px;
  margin-left: 0px;
  margin-right: 0px;
  margin-bottom: 0px;
}
.imagenes-de-la-muestra-V {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 900px; /* Asegúrate de que el contenedor tenga una altura definida */
  width: 450px;
  margin-top: 0px;
  margin-bottom: 0px;
}
.imagenes-de-la-muestra-insertar {
  margin-left: -40px;
  margin-bottom: 10px;
  margin-top: 0px;
}
.img-de-la-m {
  text-align: center;
  margin-top: 0px;
  margin-bottom: 0px;
  background-color: #ffffff;
  color: #004676;
  height: 30px;
  width: 170px;
}

.prof {
  margin-bottom: -20px;
  background-color: #ffffff;
  margin-left: 0px;
  margin-right: 0px;
}
.profesorInsertar {
  display: none;

  justify-content: space-between;
  margin-right: 24px;
  margin-top: -40px;
}

.txtProfesor-input-insertar {
  display: none;
  width: 200px;
  height: 26px;
  margin-right: 0px;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}

.muestra {
  display: flex;
  flex-direction: column;
  margin-bottom: 28px;
  background-color: #ffffff;
}

.muestra-calidad {
  display: flex;
  flex-direction: column;
  margin-top: -30px;
}

.tipo-muestra {
  display: flex;
  flex-direction: column;
  margin-bottom: 40px;
}

.tipo-muestra-tt-descrip {
  margin-top: -30px;
  margin-top: 100px;
  background-color: #ffffff;
  color: #004676;
  max-height: 30px;
  width: 300px;
  position: fixed;
}

.tip-org {
  margin-top: 0px;
  margin-bottom: 0px;
  background-color: #ffffff;
}

.texto-descrip {
  display: flex;
  margin-left: 160px;
  margin-bottom: 10px;
  margin-top: 10px;
}

.contenedor-txt-anadir {
  display: flex;
  justify-content: space-between;
  border: 20px solid #f5f5f5;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  border-bottom: 20px;
  margin-top: 0px;
  margin-left: 40px;
  margin-right: 40px;
  margin-bottom: 0px;
}

.contenedor-txt-editar {
  height: 60px;
  display: flex;
  justify-content: flex-start;
  margin-top: 20px;
  margin-left: 60px;
  margin-right: 60px;
  margin-bottom: 0px;
  background-color: #ffffff;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
}

.codigo {
  display: flex;
  margin-right: 5px;
  margin-left: 20px;
  margin-top: 20px;
  border-color: #004676;
}
.textfield-input {
  width: 150px;
  height: 26px;
  margin-left: 10px;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}
.textfield-input:focus {
  color: #004676;
  background-color: #ffffff;
}

.usuario {
  display: flex;
  margin-right: 5px;
  margin-left: 10px;
  margin-top: 20px;
  border-color: #004676;
}

.txtUsuario-input {
  width: 190px;
  height: 26px;
  margin-left: 10px;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}
.txtUsuario-input:focus {
  color: #004676;
  background-color: #ffffff;
}
.cod-fecha-user {
  display: flex;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  border-radius: 20px;
}

.fecha {
  display: flex;
  margin-right: 10px;
  margin-left: 20px;
  margin-top: 20px;
  border-color: #004676;
}

.calendar {
  display: flex;
  margin-right: 15px;
  margin-top: 26px;
  height: 20px;
}

.date-input {
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  height: 26px;
  margin-top: -6px;
  font-weight: bold;
}
.date-input:focus {
  color: #004676;
  background-color: #ffffff;
}
.select-input {
  width: 200px;
  height: 26px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  font-weight: bold;
}

.select-input:hover {
  background-color: #f5f5f5;
}

.select-input .option--highlight {
  background-color: #004676 !important;
  color: #ffffff !important;
}

.select-input-calidad {
  width: 760px;
  height: 20px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  font-size: 15px;
}

.select-input-calidad:hover {
  background-color: #f5f5f5;
}

.select-input-calidad .option--highlight {
  background-color: #004676 !important;
  color: #ffffff !important;
}

.select-input-interp {
  width: 450px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  color: #004676;
  max-height: 300px;
  overflow-y: auto;
  position: fixed;
  z-index: 1;
}

.select-input-interp .multiselect__input {
  font-size: 18px;
}

.select-input-interp .multiselect__content-wrapper {
  position: fixed;
  max-height: 300px;
  overflow-y: auto;
  width: 100%;
  z-index: 1;
}

.select-input-interp:hover {
  background-color: #f5f5f5;
}

.select-input-interp .multiselect__option--highlight {
  background-color: #004676 !important;
  color: #ffffff !important;
}

.select-input-interp .multiselect__content-wrapper {
  background-color: #ffffff;
  position: fixed;
  height: 158px;
  overflow-y: 50px;
  width: 670px;
  z-index: 1;
  border: solid 1px #004676;
}

.tt-descipcion {
  margin-top: -30px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  text-align: center;
  font-weight: bold;
}

.contenedor-txt-consulta {
  height: 750px;
  width: 100%x;
  display: flex;
  justify-content: space-between;
  border-top: 0px solid #f5f5f5;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  margin-top: 0px;
  margin-left: 60px;
  margin-right: 60px;
  margin-bottom: 20px;
  background-color: #ffffff;
}

.caja-txt {
  width: 100%;
  height: 260px;
  margin-top: 20px;
  margin-bottom: 30px;
  border: 1px solid #004676;
  background-color: #dee5ed;
  max-height: 156px;
  overflow-y: auto;
  scrollbar-color: #406985 #f1f1f1;
}

.imagen-placa,
.imagen-muestra,
.imagen-inicioP {
  border-radius: 40px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  padding: 16px;
  border: 0px;
}

h1 {
  font-weight: 500;
  font-size: 2.6rem;
  position: relative;
  top: -10px;
  text-align: left;
}

h2 {
  font-size: 22px;
  font-weight: bold;
  text-align: left;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: left;
}

.tt-imagen-consultas {
  max-width: 400px;
  background-color: #f5f5f5;
  text-align: center;
  margin: 0 auto;
  margin-top: 60px;
  padding: 10px;
  border: 1px solid #004676;
  border-bottom: 0px;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  font-weight: bold;
}

.texto-tt-consultas {
  font-weight: bold;
  color: #004676;
}

.btn-edita {
  display: flex;
  justify-content: center;
  margin-top: -20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
}

.btn-envia {
  display: flex;
  justify-content: center;
  margin-top: -20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
}
.btn-consul-edita {
  display: flex;
  justify-content: space-between;
}

.upload-btn {
  width: 175px;
  height: 32px;
  background-color: #004676;
  color: #ffffff;
  border: 0px;
  border-radius: 6px;
  margin-top: 0px;
  margin-left: 110px;
  margin-right: 0px;
  margin-bottom: 0px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.6);
}
.upload-btn:hover {
  background-color: #165c8c; /* Cambia el color de fondo al pasar el cursor por encima */
}

.btn-editar {
  width: 175px;
  height: 32px;
  background-color: #004676;
  color: #ffffff;
  border: 0px;
  border-radius: 6px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 44px;
  margin-bottom: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.6);
}
.btn-editar:hover {
  background-color: #165c8c; /* Cambia el color de fondo al pasar el cursor por encima */
}

.btn-enviar {
  width: 175px;
  height: 32px;
  background-color: #004676;
  color: #ffffff;
  border: 0px;
  border-radius: 6px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.6);
}

.btn-enviar:hover {
  background-color: #165c8c; /* Cambia el color de fondo al pasar el cursor por encima */
}

.btn-enviar:active {
  background-color: #002244; /* Cambia el color de fondo al hacer clic */
}

.container {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: repeat(2, 1fr);
  gap: 0px; /* Ajusta el espacio entre las imágenes */
  max-height: 480px;
  width: 450px;
  overflow-y: scroll; /* Agrega la barra de desplazamiento vertical */
  border: 1px solid #004676;
  margin-right: 36px;
  margin-bottom: -46px;
  margin-top: 0px;
  scrollbar-color: #004676;
}
.upload-btn-wrapper {
  margin-top: 76px;
  margin-bottom: -92px;
}

.image-container img {
  width: 100%;
  height: 90%;
  object-fit: cover;
  padding-top: 10px;
  padding-right: 10px;
  padding-left: 10px;
  padding-bottom: -10px;
  margin-bottom: -10px;
}

.image-container p {
  text-align: center;
}

.imagen-inicio {
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
}

.container::-webkit-scrollbar {
  width: 12px; /* Ancho de la barra de desplazamiento */
  height: 100px;
}

.container::-webkit-scrollbar-track {
  background: #dee5ed; /* Color de la pista de la barra de desplazamiento */
}

.container::-webkit-scrollbar-thumb {
  background: #84a3b9; /* Color del pulgar de la barra de desplazamiento */
}

.container::-webkit-scrollbar-thumb:hover {
  background: #004676; /* Color del pulgar de la barra de desplazamiento al pasar el mouse */
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
