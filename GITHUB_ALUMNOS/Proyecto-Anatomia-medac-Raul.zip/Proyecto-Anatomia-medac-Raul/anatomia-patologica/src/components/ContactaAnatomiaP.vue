<template>
  <div class="editar-container">
    <div class="tt-cabecera"></div>
    <div class="tt-imagen-consultas">
      <p class="texto-tt-consultas">CONTACTA</p>
    </div>
    <div clase="conten-gris">
      <div class="contenedor-txt-anadir">
        <div class="anadir-muestra">
          <h2>Contactar por teléfono</h2>
          <p>
            “Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
            dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
            Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
            mollit anim id est laborum.”
          </p>
          <div class="btn-comienza">
            <button class="btn-comenzar">Comenzar</button>
          </div>
        </div>
        <div>
          <img src="/contacto_telefonoP.jpg" alt="Imagen de añadir" class="imagen-muestra" />
        </div>
      </div>
      <div class="contenedor-txt-editar">
        <div class="editar-muestra">
          <h2>Contactar por email</h2>
          <p>
            “Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
            dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
            Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
            mollit anim id est laborum.”
          </p>
          <div class="btn-comienza">
            <button class="btn-comenzar">Comenzar</button>
          </div>
        </div>
        <div>
          <img src="/contacto_email.jpg" alt="Imagen de añadir" class="imagen-placa" />
        </div>
      </div>
      <!---->
      <div class="contenedor-txt-consulta">
        <div class="consultar-muestra">
          <h2>Concertar tutoría</h2>
          <p>
            “Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            exercitation ullamco late velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
            sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id
            est laborum.”
          </p>
          <div class="btn-comienza">
            <button class="btn-comenzar">Comenzar</button>
          </div>
        </div>
        <div>
          <img src="/contacto_tutor.jpg" alt="Imagen de añadir" class="imagen-inicioP" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'

export default defineComponent({
  name: 'PaginaContacto',
  props: {
    msg: String
  },
  setup() {
    const showSubmenu = ref(false)
    return { showSubmenu }
  }
})
</script>

<style scoped>
.editar-container {
  width: 1170px;
  height: auto;
  border: 0px;
}

.conten-gris {
  height: auto;
  border: 0px;
  padding-top: 10px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  background-color: #f5f5f5;
}

.anadir-muestra,
.consultar-muestra {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: left;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 0px;
  padding: 16px;
  border: 0px solid #004676;
}

.editar-muestra {
  display: flex;
  width: 100%;
  flex-direction: column;
  align-items: left;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 500px;
  padding: 16px;
  border: px solid #004676;
}

.btn-comienza {
  display: flex;
  justify-content: left;
  margin-top: 0px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 0px;
}
.btn-comenzar {
  width: 175px;
  height: 32px;
  background-color: #004676;
  color: #ffffff;
  border: 0px;
  border-radius: 6px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 10px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.6);
}

.contenedor-txt-anadir {
  display: flex;
  justify-content: space-between;
  border: 20px solid #f5f5f5;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  border-bottom: 0px;
  margin-top: 0px;
  margin-left: 60px;
  margin-right: 60px;
  margin-bottom: 0px;
}

.contenedor-txt-editar {
  height: 300px;
  display: flex;
  justify-content: space-between;
  flex-direction: row-reverse;
  border: 20px solid #f5f5f5;
  border-bottom: 0px;
  margin-top: 0px;
  margin-left: 60px;
  margin-right: 60px;
  margin-bottom: 0px;
}

.contenedor-txt-consulta {
  height: 300px;
  display: flex;
  justify-content: space-between;
  border: 20px solid #f5f5f5;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  margin-top: 0px;
  margin-left: 60px;
  margin-right: 60px;
  margin-bottom: 20px;
  background-color: #ffffff;
}

.imagen-muestra,
.imagen-inicioP {
  border-radius: 40px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 0px;
  padding: 16px;
  border: 0px;
}
.imagen-placa {
  border-radius: 40px;
  margin-top: 20px;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 300px;
  padding: 16px;
  border: 0px;
}

h1 {
  font-weight: 500;
  font-size: 2.6rem;
  position: relative;
  top: -10px;
  text-align: left;
}

h2 {
  font-size: 22px;
  font-weight: bold;
  text-align: left;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: left;
}

.tt-imagen-consultas {
  max-width: 400px;
  background-color: #f5f5f5;
  text-align: center;
  margin: 0 auto;
  margin-top: 60px;
  padding: 10px;
  border: 1px solid #004676;
  border-bottom: 0px;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  font-weight: bold;
}

.texto-tt-consultas {
  font-weight: bold;
  color: #004676;
}

.imagen-inicio {
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
