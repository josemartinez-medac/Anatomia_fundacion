import { createRouter, createWebHistory } from 'vue-router'
import Inicio from '../components/InicioAnatomiaP.vue'
import Muestras from '../components/MuestrasAnatomiaP.vue'
import Contacta from '../components/ContactaAnatomiaP.vue'
import Consultar from '../components/ConsultaAnatomiaP.vue'
import Editar from '../components/EditarAnatomiaP.vue'
import IniciarSesion from '../components/IniciarSesion.vue'
import PruebaPrueba from '../components/PruebaPrueba.vue'
import Insertar from '../components/InsertarAnatomiaP.vue'
import BuscarView from '../views/BuscarView.vue'
import InsertarAnatomiaP from '../components/InsertarAnatomiaP.vue'
import Muest from '../components/ViewMuestras.vue'

/*import Inicio from '@/components/Inicio.vue'  

// te he dejado algo escrito en PruebaPrueba.vue,
Si lo prefieres, puedes borrar lo que tengas en alguna de estas vistas que no estés usando
y empezar de 0, el codigo para empezar es: 

<template lang="">
  <div>
    
  </div>
</template>
<script>
export default {
  
}
</script>
<style lang="">
  
</style>



en el template va todo el html, en script de momento no hace falta nada, y en styles pues el css(si lo queires dejar en el mismo archivo)
cada vista que hagas nueva, escribes eso para empezar. ok, vale 
pero tiene que funcionar este archivo tambien. entiendes lo de las rutas? 
si, con las rutas hice el menu de navegacion. Lo que peor llevo es colocar los componentes en en el sitio que quiero. Me llevo mucho tiempo.
A veces no me muestra lo que quiero y solo si lo pongo en el archivo App.vue me lo muestra. Se que hay cosas que no se necesita. Es que
hago pruebas a ver como sale en la página y luego no lo he quitado. Te paso el de la de inicio? porque tu no puedes copiarlo de mi proyecto?
Vale pues te envio el codigo de la de inicio y me dices como lo ves. ok.

Esto último a que te refieres? por ejemplo que me ponga con IniciarSesión.vue y ahí luego te paso el código

Hacemos lo sigueinte: centrate en una vista y si solo la puedes ver poniendola en App.vue, pues hazlo
de todos modos lo que necesito es el codigo de tu vista, luego lo voy a pegar en el mio y alli si se verá siempre.
si puedo copiarlo. cuando este listo, me dices o me lo mandas luego por discord en privado o como quieras. 
porque esto se va a descon
vale. Ahora voy a sacar al perro, en un rato vuelvo. si quieres ponerte con otra vista en html y css como los demas, tambien es util
ya que solo necesito copiar el codigo de en medio que van a escribir y su css. luego lo pegaré en mi proyecto y haré que funcione


<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>

export default {
  
};
</script>

<style>
#app {
  font-family: Arial, sans-serif;
  text-align: center;
  margin-top: 50px;
}
</style>


a*/
import SignUpForm from '../components/SignUpForm.vue'
//import NaturalezaView from '@/views/NaturalezaView.vue'
const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/registro', component: SignUpForm },
    /*
    {
      path: '/organos',
      name: 'organos',
      component: () => import('@/views/OrganoView.vue')
    },
    */
    //{ path: '/naturaleza', component: NaturalezaView },
    { path: '/', component: Inicio },
    { path: '/iniciarsesion', component: IniciarSesion },
    {
      path: '/muestras/buscar',
      name: 'Buscar',
      component: BuscarView
    },

    {
      path: '/muestras',
      component: Muestras,
      children: [{ path: '/prueba', component: PruebaPrueba }]
    },
    { path: '/muestras/insertar', component: Insertar },
    { path: '/muestras/consultar', component: Consultar },
    { path: '/muestras/editar', component: Editar },
    { path: '/contacta', component: Contacta },
    {
      path: '/insertar-anatomia-p',
      name: 'InsertarAnatomiaP',
      component: InsertarAnatomiaP
    },
    { path: '/muest', component: Muest }
  ]
})

export default router
