<script lang="ts">
import { defineComponent } from 'vue'
import ConsultaAnatomiaP from './components/ConsultaAnatomiaP.vue'
import InsertarAnatomiaP from './components/InsertarAnatomiaP.vue'

export default defineComponent({
  name: 'App',
  components: {
    ConsultaAnatomiaP,
    InsertarAnatomiaP
  },
  data() {
    return {
      showSubmenu: false,
      isConsultarActive: false,
      isInsertarActive: false
    }
  },
  methods: {
    handleMouseEnter() {
      this.showSubmenu = true
    },
    handleMouseLeave() {
      this.showSubmenu = false
    },
    handleConsultarClick() {
      this.isConsultarActive = true
    },
    activateConsulta() {
      this.isConsultarActive = true
    },
    handleInsertarClick() {
      this.isInsertarActive = true
    },
    activateInsertar() {
      this.isInsertarActive = true
    },
    deactivateInsertar() {
      this.isInsertarActive = false
    }
  }
})
</script>

<template>
  <div id="app">
    <div class="main-container">
      <div class="tt-cabecera">
        <p class="texto-tt-cabecera">Anatomía Patológica</p>
      </div>
      <nav class="menu-background">
        <ul class="menu">
          <li><img src="/logo.png" alt="Vue logo" class="logo" /></li>
          <li><router-link to="/">Inicio</router-link></li>
          <li v-on:mouseenter="handleMouseEnter" v-on:mouseleave="handleMouseLeave">
            <router-link to="/muestras">Muestras</router-link>
            <ul v-if="showSubmenu" class="submenu">
              <li><router-link to="/muestras/insertar">Añadir </router-link></li>
              <li><router-link to="/muestras/buscar">Consultar </router-link></li>
              <li><router-link to="/muestras/editar">Editar </router-link></li>
            </ul>
          </li>
          <li><router-link to="/contacta">Contacto</router-link></li>
        </ul>
      </nav>
      <!-- Aquí es donde se renderizarán tus páginas -->
      <router-view></router-view>
    </div>
    <ConsultaAnatomiaP v-if="isConsultarActive" />
    <InsertarAnatomiaP v-if="isInsertarActive" />
  </div>
</template>

<style scoped>

  .main-container {
    border: 1px solid #004676;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    width: 100%; /* Ajusta este valor según tus necesidades */
    height: 100%;
  }

.logo {
  height: 40px;
  width: auto; /* Esto mantendrá la proporción de la imagen */
  margin-right: 20px;
  margin-left: 15px;
}

.tt-cabecera {
  width: 100%;
  background-color: #004676;
  text-align: center;
  padding: 10px;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}

.texto-tt-cabecera {
  color: #ffffff;
}

.menu-background {
  background-color: #f5f5f5;
  border-top: 6px solid #f5f5f5;
  padding: 6px 0px;
}
.menu {
  width: 100%;
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
}

.menu li {
  float: left;
}

.menu li a {
  display: block;
  color: #004676;
  text-align: center;
  padding: 6px 16px;
  text-decoration: none;
}

.menu li a:hover {
  border-radius: 10px;
}

.submenu {
  display: none;
  position: absolute;
  min-width: 160px;
  box-shadow: 0px 4px 4px -1px #00477660;
  padding: 12px 16px;
  z-index: 1;
}

.submenu li {
  display: block;
  background-color: #f5f5f500;
}

li:hover .submenu {
  display: block;
}

h1 {
  font-weight: 500;
  font-size: 16px;
  position: relative;
  top: -10px;
}

h3 {
  font-size: 10px;
  font-weight: bold;
}

.greetings h1,
.greetings h3 {
  text-align: left;
}

.tt-imagen {
  max-width: 400px;
  background-color: #f5f5f5;
  text-align: center;
  margin: 0 auto;
  margin-top: 60px;
  padding: 10px;
  border: 1px solid #004676;
  border-bottom: 0px;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  font-weight: bold;
}

.texto-tt-imagen {
  font-weight: bold;
  color: #004676;
}

.imagen-inicio {
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
}

@media (min-width: 1440px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
