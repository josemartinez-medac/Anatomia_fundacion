import { createRouter, createWebHistory } from 'vue-router';
//import LoginForm from '../components/LoginForm.vue';
//import RestorePassword from '../components/RestorePassword.vue';
//import NewPassword from '../components/NewPassword.vue';
/*import TecnicalSuport from '../components/TecnicalSuport.vue';
import BasicHeader from '../components/BasicHeader.vue';
import Muestras from '../components/ViewMuestras.vue';
import ViewRevisar from '../components/ViewRevisar.vue';
*/
const routes = [
  //{ path: '/', redirect: '/login' },
  //{ path: '/login', component: LoginForm },
  { path: '/registro', component: ()=>import('@/views/SignUpView.vue') },
  {
    path:'/organos',
    name:'organos',
    component: ()=>import('@/views/OrganoView.vue')
  },
  {
    path:'/naturalezas',
    name: 'naturalezas',
    component: ()=>import('@/views/NaturalezaView.vue')
  },
  {
    path:'/sedes',
    name: 'sedes',
    component: ()=>import('@/views/SedeView.vue')
  },
  {
    path:'/formatos',
    name: 'formatos',
    component: ()=>import('@/views/FormatoView.vue')
  },
  {
    path:'/login',
    name:'login',
    component: ()=>import('@/views/LoginView.vue')
  },
  /*{
    path:'/muestra/nueva',
    name: 'muestra-nueva',
    component: ()=>import('@/views/MuestraNuevaView.vue')
  },*/
  //{ path: '/restore-password', component: RestorePassword },
  //{ path: '/new-password', component: NewPassword },
  //{ path: '/technical-support', component: TecnicalSuport },
  //{ path: '/muestras', component: Muestras },
  /*{
    path: '/viewrevisar/:code/:nature/:dateColected/:conservation/:biopsy/:sede/:quality/:descQuality/:interpretation/:desc', 
    name: 'ViewRevisar',
    component: ViewRevisar,
    props: true
  },*/

];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;