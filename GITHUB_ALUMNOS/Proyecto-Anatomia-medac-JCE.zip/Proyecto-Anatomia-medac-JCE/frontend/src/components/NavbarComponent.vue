<template>
    <nav class="navbar-expand-lg bg-body-tertiary">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="collapse-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
                <router-link class="nav-link active" aria-current="page" to="/login" style="margin-right: 15px;height: 15px;"> Inicio </router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link active" aria-current="page" to="/register" style="margin-right: 15px;height: 15px;"> Productos </router-link>
            </li>
            <li class="nav-item">
                <router-link class="nav-link active" aria-current="page" to="/organos" style="margin-right: 15px;height: 15px;"> Servicios </router-link>
            </li>
            
          </ul>
          <div class="auth-actions" style="margin-right: 10px;">
            <span v-if="isAuthenticated">Bienvenido, {{ username.username }}</span>
            <button v-if="isAuthenticated" @click="handleLogout" class="btn btn-outline-danger ms-2">Cerrar Sesión</button>
            <router-link v-else class="btn btn-outline-primary ms-2" to="/login">Iniciar Sesión</router-link>
          </div>
          <form class="d-flex" role="search" @submit.prevent="submitForm"><!--submit.prevent sirve para que no recargue la pág cuando pulsas el buscador-->
            <input class="form-control me-2" type="search" placeholder="Buscar..." aria-label="Search" v-model="searchText">
              <button class="btn btn-outline-success" type="submit" @click="getSearch">Buscar</button>
          </form>
          
        </div>
      </div>
    </nav>
</template>
<script setup>
</script>
<style scoped>
.auth-actions {
  display: flex;
  align-items: center;
}
</style>