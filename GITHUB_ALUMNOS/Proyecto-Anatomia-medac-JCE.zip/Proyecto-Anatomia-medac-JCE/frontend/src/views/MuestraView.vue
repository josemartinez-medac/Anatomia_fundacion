<template><muestra-component></muestra-component></template>
<script setup>import MuestraComponent from '@/components/MuestraComponent.vue'</script>
