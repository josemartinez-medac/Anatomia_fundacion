<template><tipo-component></tipo-component></template>
<script setup>import TipoComponent from '@/components/TipoComponent.vue'</script>
