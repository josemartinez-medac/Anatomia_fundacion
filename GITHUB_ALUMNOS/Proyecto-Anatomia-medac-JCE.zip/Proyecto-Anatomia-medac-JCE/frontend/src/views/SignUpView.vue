<script setup>
    import NavbarComponent from '@/components/NavbarComponent.vue'
    import SignUpComponent from '@/components/SignUpComponent.vue'
</script>
<template>
    <navbar-component />
    <sign-up-component />
</template>