<template>
  <div class="about">
    <h1>This is an about pager</h1>
  </div>
</template>
