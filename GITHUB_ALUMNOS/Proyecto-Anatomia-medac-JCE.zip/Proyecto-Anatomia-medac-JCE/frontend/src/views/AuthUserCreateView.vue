<template><auth-user-create-component /></template>
<script setup>import AuthUserCreateComponent from '@/components/AuthUserCreateComponent.vue'</script>
