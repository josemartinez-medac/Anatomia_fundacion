<template><codificacion-interpretacion-component></codificacion-interpretacion-component></template>
<script setup>import CodificacionInterpretacionComponent from '@/components/CodificacionInterpretacionComponent.vue'</script>
