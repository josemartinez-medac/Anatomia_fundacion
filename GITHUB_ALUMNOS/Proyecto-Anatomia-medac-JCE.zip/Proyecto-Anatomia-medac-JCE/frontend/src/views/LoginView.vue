<script setup>
    import LoginComponent from '@/components/LoginComponent.vue'
</script>
<template>
    <h1>La 15</h1>
    <login-component />
</template>