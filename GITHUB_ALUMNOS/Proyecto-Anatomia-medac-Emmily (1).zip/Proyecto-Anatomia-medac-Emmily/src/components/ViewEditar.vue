<template>
    <UserHeader nombre="aqui va cabecera" email="hola mundo" />

    <div class="container-all-muestras" style="margin-top: 120px;">
        <div class="muestras-h2">
            <h2>Editar muestra</h2>
        </div>


        <div class="data-container">
            <div class="container-form-muestras">

                <form @submit.prevent="submitEditar">

                    <div class="container-revisar form-muestras">
                        <div class="container-row1-revisar">
                            <p><strong>Código:</strong> <input class="input-editar" type="text" value="V406732MA"></p>
                            <p><strong>Fecha muestra:</strong> <input class="input-editar" type="date" value="20-01-2024"> </p> 
                            <p> correo@medac.es</p>
                        </div>

                        <div class="container-data-img-revisar">
                            <div class="data-container">
                                <div class="container-row2-revisar">
                                    <div>
                                        <strong>Naturaleza de la muestra</strong>
                                        <select>
                                            <option name="quality" value="" selected>Biopsy</option>
                                            <option name="quality" value="a">otra opcion</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                    </div>
                                    <div class="div2">
                                        <strong>Conservación de muestra</strong>
                                        <select>
                                            <option name="quality" value="" selected>Formol</option>
                                            <option name="quality" value="a">otra opcion</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                    </div>
                                </div>

                                <strong>Descripción citológica o tisular de la muestra</strong>
                                <select class="p-revisar">
                                    <option name="quality" value="" selected>Desc 1.4 Calidad</option>
                                    <option name="quality" value="a">otra opcion</option>
                                    <option name="quality" value="b">otra</option>
                                    <option name="quality" value="c">opcion1</option>
                                    <option name="quality" value="d">otro</option>
                                    <option name="quality" value="e">opcion2</option>
                                </select>

                                <textarea class="textarea-revisar" rows="13" name="" id="">
                                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Expedita numquam impedit id laboriosam sunt explicabo doloremque ipsa, consectetur hic molestiae a? Officia itaque alias quisquam earum pariatur vero nihil nobis?
                                </textarea>
                                <br>

                                <strong>Descripciones</strong>


                                <select class="p-revisar">
                                    <option name="quality" value="" selected>Interpretación 11.15</option>
                                    <option name="quality" value="a">otra opcion</option>
                                    <option name="quality" value="b">desc2</option>
                                    <option name="quality" value="c">Desc3</option>
                                    <option name="quality" value="d">desc4</option>
                                    <option name="quality" value="e">desc5</option>
                                </select>
                                <textarea class="textarea-revisar" rows="25" name="" id="">
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi quis nostrum blanditiis maxime? Ex, qui id! Quam explicabo placeat temporibus sapiente ad molestias possimus veniam, a minima, quod voluptatem. Facere!
                                    </textarea> <br>


                            </div>


                            <div class="container-img-revisar">
                                <div>
                                    <img src="../assets/imgMuestras/fct1.jpg" alt="Vista previa de la imagen" />
                                    <select required>
                                        <option value="null" selected>Tipo de aumento</option>
                                        <option value="x4">x4</option>
                                        <option value="x10">x10</option>
                                        <option value="x40">x40</option>
                                        <option value="x100">x100</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <img src="../assets/imgMuestras/fct4.webp" alt="Vista previa de la imagen" />
                                    <select required>
                                        <option value="null" selected>Tipo de aumento</option>
                                        <option value="x4">x4</option>
                                        <option value="x10">x10</option>
                                        <option value="x40">x40</option>
                                        <option value="x100">x100</option>
                                    </select>
                                </div>

                                <div>
                                    <img src="../assets/imgMuestras/fct2.jpg" alt="Vista previa de la imagen" />
                                    <select required>
                                        <option value="null" selected>Tipo de aumento</option>
                                        <option value="x4">x4</option>
                                        <option value="x10">x10</option>
                                        <option value="x40">x40</option>
                                        <option value="x100">x100</option>
                                    </select>
                                </div>

                                <div>
                                    <img src="../assets/imgMuestras/fct3.jpg" alt="Vista previa de la imagen" />
                                    <select required>
                                        <option value="null" selected>Tipo de aumento</option>
                                        <option value="x4">x4</option>
                                        <option value="x10">x10</option>
                                        <option value="x40">x40</option>
                                        <option value="x100">x100</option>
                                    </select>
                                </div>


                            </div>


                        </div>

                        <div class="buttons-revisar">

                            <button class="enviar-revisar" type="submit">Guardar cambios</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>


<script>
import UserHeader from './HeaderUser.vue';
import { ref, onMounted } from 'vue';
import axios from 'axios';
import { useCounterStore } from '../stores/counter.js';

export default {
    components: {
        UserHeader
    },

    setup(){
        
        const submitEditar = async () => {

            

  
            
                window.location.href = '/informe';

          };

          return{
            submitEditar,
          }
    },


    name: 'ViewEditar'
};
</script>



<style src="../assets/css/revisar.css"></style>
