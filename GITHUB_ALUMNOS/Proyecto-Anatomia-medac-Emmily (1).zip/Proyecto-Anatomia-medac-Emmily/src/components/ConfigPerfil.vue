<template lang="">
    <div class="div-config" >
        <!-- 
        EL css de este archivo esta en la carpeta assets/css y se llama configPerfil.css
        <strong>Puedes eliminar este div al empezar a codificar</strong>
        -->
    </div>
</template>




<script>
export default {
    
}
</script>



<style src="../assets/css/configPerfil.css"></style>
