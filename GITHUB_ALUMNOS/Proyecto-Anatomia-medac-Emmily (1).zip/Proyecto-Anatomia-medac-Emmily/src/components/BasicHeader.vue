<template>
    <nav class="navbar-basic">
      <div class="navbar-content-basic">
        {{ title }}
      </div>
    </nav>
  </template>
  
  <script>
  export default {
    name: 'BasicHeader',
    props: {
      title: {
        type: String,
        required: true
      }
    }
  };
  </script>
  
  <style scoped>
  .navbar-basic {
    background-color: rgb(0, 70, 118, 0.8);
    color: white;
    padding: 18px 0;
    position: fixed;
    width: 100%;
    top: 0;
    left: 0;
    text-align: center;
    z-index: 1000;
  }
  
  .navbar-content-basic {
    font-size: 18px;
    font-weight: bold;
  }
  
  .container {
    padding-top: 60px;
  }
  
  .restore-password {
    max-width: 400px;
    margin: 2rem auto;
    text-align: center;
  }
  </style>
  