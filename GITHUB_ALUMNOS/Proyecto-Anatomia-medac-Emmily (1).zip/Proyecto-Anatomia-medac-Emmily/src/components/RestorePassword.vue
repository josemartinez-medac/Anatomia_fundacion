<template>
    <div>

        <BasicHeader title="Restaurar Contraseña" />

        <div class="container" style="border: none;">

            <div class="restore-password">
                <h2>Recuperar Contraseña</h2>
                <p class="small">Introduce tu email para recuperar la contraseña</p>
                <form  method="" action="/new-password" autocomplete="on">
                    <div class="form-group">
                        <input type="email" class="radius" v-model="email" placeholder="email@medac.es" required>
                    </div>
                    <button type="submit">Enviar Email</button>
                    <p class="margin">Recuerda revisar tu bandeja de spam</p>
                </form>

                <router-link to="/login"><i class="bi bi-arrow-left-circle-fill arrow"></i></router-link>

            </div>
        </div>
    </div>
</template>


<script>
import BasicHeader from '@/components/BasicHeader.vue';
export default {
  components: {
    BasicHeader
  },
  data() {
    return {
      email: ''
    };
  },
  methods: {
    sendEmail() {
      // lógica de enviar el email recuperación
      console.log(`Enviando email a: ${this.email}`);
    }
  }
};
</script>



<style src="../assets/css/auth.css"></style>