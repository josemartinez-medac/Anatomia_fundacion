<template>
    <div class="body">

      <BasicHeader title="Soporte Técnico" />

        <div class="technical-support">
        <div class="form-container">
            <img src="../assets/ordenador.svg" alt="Logo Medac" class="logo" />
            <div class="form-content">
                <div class="content-form">
                    <h2>Explícanos tu problema</h2>
                    <form class="form-suport"@submit.prevent="handleSubmit">
                        <div class="form-group">
                            <label for="email">Correo electrónico:</label>
                            <input class="input-suport"type="email" id="email" v-model="email" placeholder="tuCorreo@medac.es" required />
                        </div>
                        <div class="form-group">
                            <label for="description">Descripción del problema:</label>
                            <textarea class="input-suport"rows="5" id="description" v-model="description"
                            placeholder="Describe el problema..." required></textarea>
                        </div>
                        <button type="submit">Enviar</button>
                    </form>
                </div>
                <div class="contact-info">
                    <img src="../assets/movil.svg" alt="Logo Medac"  />
                    <h2>O llámanos al <br> 6498734508 </h2>
                    
                </div>
            </div>
        </div>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <h1>aqui pie de pagina</h1>
</div>
</template>

<script>
import BasicHeader from '@/components/BasicHeader.vue';
export default {
    components: {
    BasicHeader
  },
    data() {
        return {
            email: '',
            description: ''
        };
    },
    methods: {
        handleSubmit() {
            // Aquí puedes manejar el envío del formulario, por ejemplo, enviando los datos a una API
            console.log('Email:', this.email);
            console.log('Descripción:', this.description);
        }
    }
};
</script>




<style src="../assets/css/support.css"></style>