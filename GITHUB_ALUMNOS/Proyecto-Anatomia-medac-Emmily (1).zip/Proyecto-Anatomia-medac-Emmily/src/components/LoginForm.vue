<template>
    <div class="container"> 
        <div class="title">
          inicio de sesión
        </div>
  
        <img src="../assets/logoMedac.png" width="300" alt="">
        <h3>Bienvenido a Fundación Medac</h3>
  
        <form @submit.prevent="Login">
          <div>
            <input type="email" id="email" v-model="email" placeholder="Email" required>
          </div>
          <div>
            <input type="password" id="password" v-model="password" placeholder="Contraseña" required>
          </div>
          <router-link to="/signup">Regístrate para iniciar sesión</router-link> <br>
          <button type="submit">Iniciar Sesión</button>
        </form>
  
  
        <div class="container-a">
          <router-link to="/restore-password">He olvidado mi contraseña</router-link>
          <router-link to="/technical-support">Soporte técnico</router-link>
        </div>
        
        
                

        
        
      </div>
  
 
  </template>
  
  <script>
  import { ref, onMounted } from 'vue';
  import axios from 'axios';
      
export default {
    setup() {
      const email = ref('');
      const password = ref('');
  
      const Login = async () => {
        try {
          const response = await axios.post('http://localhost:8000/api/login/', { //apuntar a la ruta que corresponda
            email: email.value,
            password: password.value,
          });
          
        } catch (error) {
          console.error('Error login:', error.response.data);
        }
      };
  
  
      return {
        email,
        password,
        Login
      };
    }
  };

  </script>
  



  <style src="../assets/css/auth.css" ></style>
  
