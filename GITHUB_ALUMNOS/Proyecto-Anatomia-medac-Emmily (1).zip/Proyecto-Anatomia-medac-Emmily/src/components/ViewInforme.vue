<template>
    <UserHeader nombre="aqui va cabecera" email="hola mundo" />

    <div class="container-all-muestras" style="margin-top: 120px;">
        <div class="muestras-h2">
            <h2>Nuevo Informe</h2>
        </div>


        <div class="data-container">
            <div class="container-form-muestras" >

                <form  @submit.prevent="submitForm">

                    <div class="container-revisar form-muestras">
                        <div class="container-row1-revisar">
                            <p><strong>Código:</strong> V406732MA</p>
                            <p><strong>Fecha muestra:</strong> 20-01-2024</p>
                            <p> correo@medac.es</p> 
                        </div>

                        <div class="container-data-img-revisar">
                            <div class="data-container">
                                <div class="container-row2-revisar">
                                    <div>
                                        <strong>Naturaleza de la muestra</strong>
                                        <p>Biopsy</p>
                                    </div>
                                    <div class="div2">
                                        <strong>Conservación de muestra</strong>
                                        <p>Formol</p>
                                    </div>
                                </div>

                                <strong>Descripción citológica o tisular de la muestra</strong>
                                <p class="p-revisar">Desc 1.4 Calidad</p>

                                <textarea readonly class="textarea-revisar" rows="13" name="" id="">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem repellendus tenetur totam tempore temporibus et molestiae dolores dicta? Necessitatibus quisquam distinctio ipsam inventore hic laborum ipsum exercitationem quidem aliquam ducimus!
                                </textarea>
                                <br>

                                <p class="p-revisar"> Interpretación 11.15</p>

                                <textarea readonly class="textarea-revisar" rows="25" name="" id="">
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. At, ipsum non a explicabo odit dicta vitae quis, saepe voluptatem fugit animi cumque ipsa reprehenderit facilis iste ut accusamus provident velit!
                                </textarea> <br>

                            </div>


                            <div class="container-img-informe">
                                <div>
                                    <img src="../assets/imgMuestras/fct1.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct2.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct3.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct4.webp" alt="Vista previa de la imagen" />
                                </div>
                            </div>
                        </div>

                        <div class="buttons-revisar">
                            <router-link class="enviar-revisar" to="/editar">Editar muestra</router-link>

                            <!-- <button class="enviar-revisar" type="submit">Editar muestra</button>    en este boton se debe enviar el ID de la muestra concreta que se quiere editar(id de la bbdd) -->
                        </div>
                    </div>
                </form>
            </div>


            <!-- a partir de aqui es solamente codigo de simulacion, una vez los datos se estén recuperando de la base de datos, eliminar todo el siguiente codigo: -->
            <div class="container-form-muestras" >

                <form  @submit.prevent="submitForm">

                    <div class="container-revisar form-muestras">
                        <div class="container-row1-revisar">
                            <p><strong>Código:</strong> 7368934C</p>
                            <p><strong>Fecha muestra:</strong> 22-03-2024</p>
                            <p> correo@medac.es</p> 
                        </div>

                        <div class="container-data-img-revisar">
                            <div class="data-container">
                                <div class="container-row2-revisar">
                                    <div>
                                        <strong>Naturaleza de la muestra</strong>
                                        <p>Biopsia</p>
                                    </div>
                                    <div class="div2">
                                        <strong>Conservación de muestra</strong>
                                        <p>Formol</p>
                                    </div>
                                </div>

                                <strong>Descripción citológica o tisular de la muestra</strong>
                                <p class="p-revisar"> Calidad de la muestra C.1</p>

                                <textarea readonly class="textarea-revisar" rows="13" name="" id="">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem repellendus tenetur totam tempore temporibus et molestiae dolores dicta? Necessitatibus quisquam distinctio ipsam inventore hic laborum ipsum exercitationem quidem aliquam ducimus!
                                </textarea>
                                <br>

                                <p class="p-revisar"> Interpretación de la muestra 11.15</p>

                                <textarea readonly class="textarea-revisar" rows="25" name="" id="">
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. At, ipsum non a explicabo odit dicta vitae quis, saepe voluptatem fugit animi cumque ipsa reprehenderit facilis iste ut accusamus provident velit!
                                </textarea> <br>

                            </div>


                            <div class="container-img-informe">
                                <div>
                                    <img src="../assets/imgMuestras/fct3.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct1.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct4.webp" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct2.jpg" alt="Vista previa de la imagen" />
                                </div>
                            </div>
                        </div>

                        <div class="buttons-revisar">
                            <button class="enviar-revisar" type="submit">Editar muestra</button>
                        </div>
                    </div>
                </form>
            </div>


            <div class="container-form-muestras" >

                <form  @submit.prevent="submitForm">

                    <div class="container-revisar form-muestras">
                        <div class="container-row1-revisar">
                            <p><strong>Código:</strong> 7368934C</p>
                            <p><strong>Fecha muestra:</strong> 22-03-2024</p>
                            <p> correo@medac.es</p> 
                        </div>

                        <div class="container-data-img-revisar">
                            <div class="data-container">
                                <div class="container-row2-revisar">
                                    <div>
                                        <strong>Naturaleza de la muestra</strong>
                                        <p>Biopsia</p>
                                    </div>
                                    <div class="div2">
                                        <strong>Conservación de muestra</strong>
                                        <p>Formol</p>
                                    </div>
                                </div>

                                <strong>Descripción citológica o tisular de la muestra</strong>
                                <p class="p-revisar"> Calidad de la muestra C.1</p>

                                <textarea readonly class="textarea-revisar" rows="13" name="" id="">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem repellendus tenetur totam tempore temporibus et molestiae dolores dicta? Necessitatibus quisquam distinctio ipsam inventore hic laborum ipsum exercitationem quidem aliquam ducimus!
                                </textarea>
                                <br>

                                <p class="p-revisar"> Interpretación de la muestra 11.15</p>

                                <textarea readonly class="textarea-revisar" rows="25" name="" id="">
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. At, ipsum non a explicabo odit dicta vitae quis, saepe voluptatem fugit animi cumque ipsa reprehenderit facilis iste ut accusamus provident velit!
                                </textarea> <br>

                            </div>


                            <div class="container-img-informe">
                                <div>
                                    <img src="../assets/imgMuestras/fct2.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct1.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct4.webp" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct3.jpg" alt="Vista previa de la imagen" />
                                </div>
                            </div>
                        </div>

                        <div class="buttons-revisar">
                            <button class="enviar-revisar" type="submit">Editar muestra</button>
                        </div>
                    </div>
                </form>
            </div>


            <div class="container-form-muestras" >

                <form  @submit.prevent="submitForm">

                    <div class="container-revisar form-muestras">
                        <div class="container-row1-revisar">
                            <p><strong>Código:</strong> 7368934C</p>
                            <p><strong>Fecha muestra:</strong> 22-03-2024</p>
                            <p> correo@medac.es</p> 
                        </div>

                        <div class="container-data-img-revisar">
                            <div class="data-container">
                                <div class="container-row2-revisar">
                                    <div>
                                        <strong>Naturaleza de la muestra</strong>
                                        <p>Biopsia</p>
                                    </div>
                                    <div class="div2">
                                        <strong>Conservación de muestra</strong>
                                        <p>Formol</p>
                                    </div>
                                </div>

                                <strong>Descripción citológica o tisular de la muestra</strong>
                                <p class="p-revisar"> Calidad de la muestra C.1</p>

                                <textarea readonly class="textarea-revisar" rows="13" name="" id="">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem repellendus tenetur totam tempore temporibus et molestiae dolores dicta? Necessitatibus quisquam distinctio ipsam inventore hic laborum ipsum exercitationem quidem aliquam ducimus!
                                </textarea>
                                <br>

                                <p class="p-revisar"> Interpretación de la muestra 11.15</p>

                                <textarea readonly class="textarea-revisar" rows="25" name="" id="">
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. At, ipsum non a explicabo odit dicta vitae quis, saepe voluptatem fugit animi cumque ipsa reprehenderit facilis iste ut accusamus provident velit!
                                </textarea> <br>

                            </div>


                            <div class="container-img-informe">
                                <div>
                                    <img src="../assets/imgMuestras/fct2.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct3.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct1.jpg" alt="Vista previa de la imagen" />
                                    <img src="../assets/imgMuestras/fct4.webp" alt="Vista previa de la imagen" />
                                </div>
                            </div>
                        </div>

                        <div class="buttons-revisar">
                            <button class="enviar-revisar" type="submit">Editar muestra</button>
                        </div>
                    </div>
                </form>
            </div>
          <!-- eliminar hasta aqui -->



        </div>
    </div>
</template> 


<script>
import UserHeader from './HeaderUser.vue';
import { ref, onMounted } from 'vue';
import axios from 'axios';

export default {
    
    components: {
        UserHeader
    },

    name: 'ViewRevisar'
};
</script>



<style src="../assets/css/revisar.css"></style>
