<template lang="">
    <div class="div-contacta">
        (el css de este archivo se llama contacta.css y está en la carpeta assets/css)
         <strong>Puedes eliminar este div al empezar a codificar</strong>
      </div>

    <div class="container-all-muestras">
      <h2>Contacta</h2>

      <div class="muestras-h2">
        aqui va texto  [IMAGEN]
      </div>

      <div class="muestras-h2">
        [IMAGEN] aqui texto
      </div>
      
      <div class="muestras-h2">
        aqui va texto  [IMAGEN]
      </div>
      
    </div>
        
</template>




<script>
export default {

}
</script>



<style src="../assets/css/contacta.css"></style>