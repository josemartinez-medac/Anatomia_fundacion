import { createRouter, createWebHistory } from 'vue-router';
import LoginForm from '../components/LoginForm.vue';
import SignUpForm from '../components/SignUpForm.vue';
import RestorePassword from '../components/RestorePassword.vue';
import NewPassword from '../components/NewPassword.vue';
import TecnicalSuport from '../components/TecnicalSuport.vue';
import Muestras from '../components/ViewMuestras.vue';
import Muestras2 from '../components/ViewMuestras2.vue';
import ViewRevisar from '../components/ViewRevisar.vue';
import HeaderUser from '../components/HeaderUser.vue';
import Contacta from '../components/ContactaNos.vue';
import Update from '../components/UpdateProfile.vue';
import Informe from '../components/ViewInforme.vue';
import Buscar from '../components/viewBuscar.vue';
import Editar from '../components/ViewEditar.vue';

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: LoginForm },
  { path: '/signup', component: SignUpForm },
  { path: '/restore-password', component: RestorePassword },
  { path: '/new-password', component: NewPassword },
  { path: '/technical-support', component: TecnicalSuport },
  { path: '/muestras', component: Muestras },
  { path: '/muestras2/:code/:nature/:dateColected/:conservation/:biopsy/:sede/:imgUrls',
    component: Muestras2, 
    name: 'ViewMuestras2',
    props: true },
  { path: '/headerUser', component: HeaderUser },
  { path: '/contacta', component: Contacta },
  { path: '/updateProfile', component: Update },
  { path: '/informe', component: Informe },
  {
    path: '/viewrevisar/:code/:nature/:dateColected/:conservation/:biopsy/:sede/:quality/:descQuality/:interpretations/:imgUrls', 
    name: 'ViewRevisar', 
    component: ViewRevisar,
    props: true
    },
  { path: '/buscar', component: Buscar },
  { path: '/editar', component: Editar },
  
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
