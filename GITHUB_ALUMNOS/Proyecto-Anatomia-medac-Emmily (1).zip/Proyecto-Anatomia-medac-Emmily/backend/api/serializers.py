from django.contrib.auth.models import User;
from rest_framework.serializers import ModelSerializer
from .models import Tipo,Sede,Naturaleza,Formato,Estado,Organo,CodificacionInterpretacion,Muestra,Aumento,Imagen
class TipoSerializer(ModelSerializer):
    class Meta:
        model=Tipo
        fields=['tipo']
class SedeSerializer (ModelSerializer):
    class Meta:
        model=Sede
        fields=["sede","codigo"]
class NaturalezaSerializer (ModelSerializer):
    class Meta:
        model=Naturaleza
        fields=["codigo","naturaleza"]
class FormatoSerializer (ModelSerializer):
    class Meta:
        model=Formato
        fields=["formato"]
class EstadoSerializer (ModelSerializer):
    class Meta:
        model=Estado
        fields=["estado","comentario"]
class OrganoSerializer (ModelSerializer):
    class Meta:
        model=Organo
        fields=["organo","codigo"]
class CodificacionInterpretacionSerializer (ModelSerializer):
    class Meta:
        model=CodificacionInterpretacion
        fields=["organo","naturaleza","tipo","codigo","descripcion"]
class MuestraSerializer (ModelSerializer):
    class Meta:
        model=Muestra
        fields=["fecha_recepcion","naturaleza", "formato", "organo", "sede","estado","username"]
class AumentoSerializer (ModelSerializer):
    class Meta:
        model=Aumento
        fields=["zoom"]
class ImagenSerializer (ModelSerializer):
    class Meta:
        model=Imagen
        fields=["imagen","zoom"]
class AuthUserSerializer (ModelSerializer):
    class Meta:
        model=User
        fields=["url","username","email","password","is_staff"]