from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import TipoViewSet
router=DefaultRouter()
router.register(r'tipos',TipoViewSet)
urlpatterns = [
    path('api-auth/',include('rest_framework.urls'),name='rest_framework'),
    path('',include(router.urls)),   
]