<script setup>
    import NavbarComponent from '@/components/NavbarComponent.vue';
    import MenuMuestraComponent from '@/components/MenuMuestraComponent.vue'
</script>
<template>
    <navbar-component />
    <div>      
            <menu-muestra-component/>
    </div>
</template>
<style>
.container{
    margin-top: 120px;
}
</style>