<script setup>
  import NavbarComponent from '@/components/NavbarComponent.vue'
  import InicioAnatomiaP from '@/components/InicioAnatomiaP.vue'
</script>
<template>
  <navbar-component/>
  <InicioAnatomiaP />
</template>
