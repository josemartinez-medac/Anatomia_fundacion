<script setup>
    import NavbarComponent from '@/components/NavbarComponent.vue';
    import MenuMuestraComponent from '@/components/MenuMuestraComponent.vue'
</script>
<template>
    
    <navbar-component />
    <menu-muestra-component />

</template>
<style>

</style>