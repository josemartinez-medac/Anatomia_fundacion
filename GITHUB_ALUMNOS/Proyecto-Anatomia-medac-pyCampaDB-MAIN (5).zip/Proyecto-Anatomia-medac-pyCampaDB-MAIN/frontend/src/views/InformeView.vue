<script setup>
import NavbarComponent from '@/components/NavbarComponent.vue'
import InformeComponent from '@/components/InformeComponent.vue'
</script>
<template>
    <navbar-component />
    <informe-component />
</template>