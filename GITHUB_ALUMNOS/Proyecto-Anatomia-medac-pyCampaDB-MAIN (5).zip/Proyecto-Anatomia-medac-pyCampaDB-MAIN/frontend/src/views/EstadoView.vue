<template><estado-component></estado-component></template>
<script setup>import EstadoComponent from '@/components/EstadoComponent.vue'</script>
