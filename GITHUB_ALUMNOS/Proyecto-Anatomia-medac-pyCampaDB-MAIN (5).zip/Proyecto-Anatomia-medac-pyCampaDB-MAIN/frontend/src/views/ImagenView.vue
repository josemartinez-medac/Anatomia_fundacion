<template><imagen-component></imagen-component></template>
<script setup>import ImagenComponent from '@/components/ImagenComponent.vue'</script>
