<template><aumento-component></aumento-component></template>
<script setup>import AumentoComponent from '@/components/AumentoComponent.vue'</script>
