<script setup>
import NavbarComponent from '@/components/NavbarComponent.vue'
import ViewMuestras from '@/components/ViewMuestras.vue'
</script>
<template><navbar-component /><ViewMuestras /></template>
