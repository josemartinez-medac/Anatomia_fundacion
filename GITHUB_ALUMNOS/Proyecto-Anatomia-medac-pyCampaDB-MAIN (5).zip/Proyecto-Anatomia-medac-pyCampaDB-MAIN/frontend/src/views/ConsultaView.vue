<script setup>
import NavbarComponent from '@/components/NavbarComponent.vue';
import ConsultaComponent from '@/components/ConsultaComponent.vue'; 
</script>
<template>
    <navbar-component />
    <consulta-component />
</template>