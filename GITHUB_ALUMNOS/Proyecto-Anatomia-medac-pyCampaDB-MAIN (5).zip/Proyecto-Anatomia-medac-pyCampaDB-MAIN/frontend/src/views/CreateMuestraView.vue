<template><create-muestra-component></create-muestra-component></template>
<script setup>import CreateMuestraComponent from '@/components/CreateMuestraComponent.vue'</script>
