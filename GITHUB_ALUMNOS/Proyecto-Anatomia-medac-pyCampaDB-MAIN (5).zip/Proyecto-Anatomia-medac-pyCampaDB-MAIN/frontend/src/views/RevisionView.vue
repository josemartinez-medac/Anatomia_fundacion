<script setup>
    import NavbarComponent from '@/components/NavbarComponent.vue'
    import ViewRevisar from '@/components/ViewRevisar.vue'
</script>
<template>
    <navbar-component />
    <ViewRevisar />
</template>