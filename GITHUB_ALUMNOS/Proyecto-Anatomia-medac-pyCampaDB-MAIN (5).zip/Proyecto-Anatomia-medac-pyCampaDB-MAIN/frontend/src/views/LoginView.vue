<script setup>
    import LoginComponent from '@/components/LoginComponent.vue'
    import NavbarComponent from '@/components/NavbarComponent.vue'
</script>
<template>
    <navbar-component />
    <login-component />
</template>

