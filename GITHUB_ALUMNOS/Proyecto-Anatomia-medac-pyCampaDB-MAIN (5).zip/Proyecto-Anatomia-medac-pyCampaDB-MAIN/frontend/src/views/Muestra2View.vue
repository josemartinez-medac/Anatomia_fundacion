<script setup>
    import NavbarComponent from '@/components/NavbarComponent.vue'
    import ViewMuestras2 from '@/components/ViewMuestras2.vue'
</script>
<template>
    <navbar-component />
    <ViewMuestras2 />
</template>