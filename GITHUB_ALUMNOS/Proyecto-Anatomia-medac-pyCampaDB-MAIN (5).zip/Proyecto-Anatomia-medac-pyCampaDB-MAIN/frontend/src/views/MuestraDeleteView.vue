<template><muestra-delete-component></muestra-delete-component></template>
<script setup>import MuestraDeleteComponent from '@/components/MuestraDeleteComponent.vue'</script>
