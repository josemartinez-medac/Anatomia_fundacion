<template>
  <div id="app">
    <navbar-component />
    <router-view />
  </div>
</template>

<script>
export default {};
</script>

<style>
#app {
  font-family: Arial, sans-serif;
  text-align: center;
  margin-top: 50px;
}
</style>
