import { createRouter, createWebHistory } from 'vue-router';
import LoginForm from '../components/LoginForm.vue';
import SignUpForm from '../components/SignUpForm.vue';
import RestorePassword from '../components/RestorePassword.vue';
import NewPassword from '../components/NewPassword.vue';
import TecnicalSuport from '../components/TecnicalSuport.vue';
import Muestras from '../components/ViewMuestras.vue';
import Muestras2 from '../components/ViewMuestras2.vue';
import ViewRevisar from '../components/ViewRevisar.vue';
import HeaderUser from '../components/HeaderUser.vue';
import Contacta from '../components/ContactaNos.vue';
import Update from '../components/UpdateProfile.vue';
import Buscar from '../components/BuscarView.vue';
//import Informe from '../components/ViewInforme.vue';
import Prueba from '../components/Prueba.vue';

const routes = [
  { path: '/prueba', component: Prueba},
  { path: '/buscar', component: Buscar},
  { path: '/', redirect: '/login' },
  { path: '/login', component: LoginForm },
  { path: '/signup', component: SignUpForm },
  { path: '/restore-password', component: RestorePassword },
  { path: '/new-password', component: NewPassword },
  { path: '/technical-support', component: TecnicalSuport },
  { path: '/muestras', component: Muestras },
  { path: '/muestras2/:code/:nature/:dateColected/:conservation/:biopsy/:sede/:imgUrls',
   component: Muestras2, 
   name: 'ViewMuestras2',
    props: true },
  { path: '/headerUser', component: HeaderUser },
  { path: '/contacta', component: Contacta },
  { path: '/updateProfile', component: Update },
 // { path: '/informe', component: Informe },
  {
    path: '/viewrevisar/:code/:nature/:dateColected/:conservation/:biopsy/:sede/:quality/:descQuality/:interpretations/:imgUrls', 
    name: 'ViewRevisar', 
    component: ViewRevisar,
    props: true
  }
  
  
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
