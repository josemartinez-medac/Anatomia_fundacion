<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>

export default {
  
};
</script>

<style>
#app {
  font-family: Arial, sans-serif;
  display: flex;
  justify-content: center; /* Centra el contenido horizontalmente */
  align-items: flex-start; /* Alinea el contenido en la parte superior */
  text-align: center;
  margin-top: 0px;
  width: 1100px; 
  height: 1224px;
  overflow-y: hidden;
}

@media (max-width: 800px) {
  #app {
    max-width: 100%;
  }
}
</style>
