<template>
    <UserHeader nombre="aqui va cabecera" email="hola mundo" />
 
    <div class="container-all-consultas" style="margin-top: 120px;">
        <div class="consulta-informes">
            <h2>Consulta de Informes</h2>
        </div>


        <div class="data-container">
            <div class="container-form-muestras">

                <form  @submit.prevent="submitForm">

                    <div class="container-revisar-form-muestras">
                        <div class="container-row1-revisar">
                            <p><strong>Código:</strong> {{ code }}</p>
                            <p><strong>Fecha muestra:</strong> {{ dateColected }}</p>
                            <p> correo@medac.es</p> 
                        </div>

                        <div class="container-data-img-revisar">
                            <div class="data-container">
                                <div class="container-row2-revisar">
                                    <div>
                                        <strong>Naturaleza de la muestra</strong>
                                        <select>
                                            <option name="quality" value="" selected>{{ conservation }}</option>
                                            <option name="quality" value="a">Biopsia</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                    </div>
                                    <div class="div2">
                                        <strong>Conservación de muestra</strong>
                                        <select>
                                            <option name="quality" value="" selected>{{ conservation }}</option>
                                            <option name="quality" value="a">Formol</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                    </div>
                                </div class="data-container2">
                                    <div class="row3">
                                        <div class="container-row3-organo">
                                            <div class="organo">
                                        <strong>Tipo de Órgano</strong>
                                        <select>
                                            <option name="quality" value="" selected>{{ conservation }}</option>
                                            <option name="quality" value="a">Corazón</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                            </div>
                                        </div>
                                        <div class="container-row3-sede">
                                            <div class="sede">
                                        <strong>Centro de estudios</strong>
                                        <select>
                                            <option name="quality" value="" selected>{{ conservation }}</option>
                                            <option name="quality" value="a">Sevilla</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                            </div>
                                        </div>
                                    </div>                      
                                   
                                
                                <strong>Descripción citológica o tisular de la muestra</strong>
                                
                                <div class="container-cali-inter">
                                    <div class="container-row4-revisar">
                                        <div class="calidad">
                                        <strong>Calidad</strong>
                                        <select>
                                            <option name="quality" value="" selected>{{ conservation }}</option>
                                            <option name="quality" value="a">otra opcion</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                        <textarea class="scrollable-textarea-calidad"></textarea>
                                    </div>
                                   

                                    <div class="container-row5-revisar">
                                        <div class="interpretacion">
                                            <strong>Interpretación</strong>
                                            <select>
                                                <option name="quality" value="" selected>{{ conservation }}</option>
                                                <option name="quality" value="a">otra opcion</option>
                                                <option name="quality" value="b">otra</option>
                                                <option name="quality" value="c">opcion1</option>
                                                <option name="quality" value="d">otro</option>
                                                <option name="quality" value="e">opcion2</option>
                                            </select>
                                            <textarea class="scrollable-textarea-interpretacion"></textarea>
                                        </div>
                                     
                                    </div>
                                </div>
                                

                            </div>                             


                                <div v-for="(interpretation, index) in interpretationsArray" :key="index">
                                    <p class="p-revisar"> {{ interpretation.interpretation }}</p>
                                    <textarea class="textarea-revisar" rows="10" name="" id="">{{ interpretation.desc }}</textarea> <br>
                                  </div>
                                  
                                  
                            </div>


                            <div class="container-img-revisar">
                                <div v-for="(image, index) in imagePath" :key="index">
                                    <div class="image-group">
                                    <div class="image-pair">
                                        <img :src="imagePath[index]" alt="Imagen de muestra1">                               
                                        <select v-model="imagesAumentos[index]" class="small-select" required>
                                    <option value="null" selected>Tipo de aumento</option>
                                    <option value="x4">x4</option>
                                    <option value="x10">x10</option>
                                    <option value="x40">x40</option>
                                    <option value="x100">x100</option>
                                    </select>
                                    </div>
                                    <div class="image-pair">
                                        <img :src="imagePath[index]" alt="Imagen de muestra2">                               
                                        <select v-model="imagesAumentos[index]" class="small-select" required>
                                    <option value="null" selected>Tipo de aumento</option>
                                    <option value="x4">x4</option>
                                    <option value="x10">x10</option>
                                    <option value="x40">x40</option>
                                    <option value="x100">x100</option>
                                    </select>
                                    </div>
                                    </div>
                                    <div class="image-group">
                                    <div class="image-pair">
                                        <img :src="imagePath[index]" alt="Imagen de muestra3">                               
                                        <select v-model="imagesAumentos[index]" class="small-select" required>
                                    <option value="null" selected>Tipo de aumento</option>
                                    <option value="x4">x4</option>
                                    <option value="x10">x10</option>
                                    <option value="x40">x40</option>
                                    <option value="x100">x100</option>
                                    </select>
                                    </div>
                                    <div class="image-pair">
                                        <img :src="imagePath[index]" alt="Imagen de muestra4">                               
                                        <select v-model="imagesAumentos[index]" class="small-select" required>
                                    <option value="null" selected>Tipo de aumento</option>
                                    <option value="x4">x4</option>
                                    <option value="x10">x10</option>
                                    <option value="x40">x40</option>
                                    <option value="x100">x100</option>
                                    </select>
                                    </div>
                                    </div>
  


  <!--

                                <select v-model="imagesAumentos[index]" class="small-select" required>
                                <option value="null" selected>Tipo de aumento</option>
                                <option value="x4">x4</option>
                                <option value="x10">x10</option>
                                <option value="x40">x40</option>
                                <option value="x100">x100</option>
                                </select>
                                -->
                                </div>
                            </div>
                            
                            
                        </div>
                        <div class="container-btn-buscar">
                        <div class="buttons-buscar">
                            <!-- <button class="volver-revisar">Volver</button> -->
                            <button class="btn-buscar" type="submit">Buscar</button>
                        </div>
                    </div>
                    </div>
                </form>
            </div>

            
        </div>
    </div>

</template> 


<script>
import UserHeader from './HeaderUser.vue';
import { ref, onMounted } from 'vue';
import axios from 'axios';
import { useCounterStore } from '../stores/counter.js';

export default {
  components: {
    UserHeader
  },
  props: [
    'code', 'nature', 'dateColected', 'conservation', 'biopsy', 'sede',
    'quality', 'descQuality', 'calidad', 'interpretations', 'imgUrls'
  ],  
  data() {
    return {
        imagePath: ['/x4.jpeg','/x10.png','/x40.png','/x100.png'],
      interpretationsArray: [],      
      imagesAumentos: []
    };
  },
  mounted() {
  this.interpretationsArray = JSON.parse(this.interpretations);
  const counterStore = useCounterStore();

  // Comprueba si counterStore.images está definido y tiene longitud mayor que 0
  if (counterStore.images && counterStore.images.length > 0) {
    this.images = counterStore.images;
    this.imageAumentos = new Array(this.images.length).fill(null);
  } else {
    // Si counterStore.images no está definido o no tiene imágenes, muestra un mensaje de error o maneja la situación como prefieras
    console.error('No images found in counterStore.images');
  }

  console.log('Props from ViewMuestras:', this.code, this.nature, this.dateColected, this.conservation, this.biopsy, this.sede);
  console.log('Props from ViewMuestras2:', this.quality, this.descQuality, this.interpretationsArray, this.imgUrls);
},


  name: 'BuscarView'
};
</script>



<style src="../assets/css/buscar.css"></style>
