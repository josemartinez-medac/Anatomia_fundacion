<template>
  <div>
    <BasicHeader title="Nueva contraseña" />

    <div class="container" style="border: none;">
      <div class="restore-password">
        <h2>Restablecer Contraseña</h2>
        <p class="small">Introduce tu nueva contraseña</p>
        <form @submit.prevent="resetPassword" autocomplete="on">
          <div class="form-group">
            <input type="password" class="radius" v-model="password" placeholder="Nueva contraseña" required>
          </div>
          <p class="small">Verifica tu nueva contraseña</p>
          <div class="form-group">
            <input type="password" class="radius" v-model="confirmPassword" placeholder="Confirmar contraseña" required>
          </div>
          <button type="submit">Restablecer Contraseña</button>
        </form>

        <router-link to="/restore-password">
          <i class="bi bi-arrow-left-circle-fill arrow"></i>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
import BasicHeader from '@/components/BasicHeader.vue';
export default {
  components: {
    BasicHeader
  },
  data() {
    return {
      password: '',
      confirmPassword: ''
    };
  },
  methods: {
    resetPassword() {
      if (this.password === this.confirmPassword) {
        //logica restaurar 
        console.log(`Restableciendo contraseña para: ${this.password}`);
        this.$router.push('/login');
      } else {
        console.log('Las contraseñas no coinciden.');
        alert('Las contraseñas no coinciden.');
      }
    }
  }
};
</script>


<style src="../assets/css/auth.css"></style>