<template lang="">
    <div class="header-top-bar">
        <span>Anatomía patológica</span>
      </div>
      <nav class="navbar-user">
        <div class="navbar-content-user">
          <div class="navbar-left">
            <img src="../assets/logoMedac.png" width="100" class="logo-header" />
          </div>
          <div class="navbar-center">
            <a href="#">Inicio</a>
            <a href="#">Muestras</a>
            <a href="#">Contacta</a>
          </div>
          <div class="navbar-right">
            <div class="user-info">Nombre [foto] ejplo@medac.es</div>
          </div>
        </div>
      </nav>
     
</template>





<script>
export default {
  name: 'UserHeader',
    // props: {
    //   nombre: {
    //     type: String,
    //     required: true,
    //   },
    //   email: {
    //     type: String,
    //     required: true,
    //   }
    // }
}
</script>


<style src="../assets/css/headerUser.css"></style>