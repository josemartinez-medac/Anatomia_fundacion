<template>
  <!--
    <nav class="navbar">
      <div class="navbar-content">
        {{ title }}
      </div>
    </nav>
-->
  </template>
  
  <script>
  export default {
    name: 'BasicHeader',
    props: {
      title: {
        type: String,
        required: true
      }
    }
  };
  </script>
  
  <style scoped>
  .navbar {
    background-color: rgb(0, 70, 118, 0.8);
    color: white;
    padding: 18px 0;
    position: relative;
    width: 100%;
    top: 0;
    left: 0;
    text-align: center;
    z-index: 1000;

  }
  
  .navbar-content {
    font-size: 18px;
    font-weight: bold;
    position: relative;
  }
  
  .container {
    padding-top: 60px;
    position: relative;
  }
  
  .restore-password {
    max-width: 400px;
    margin: 2rem auto;
    text-align: center;
  }
  </style>
  