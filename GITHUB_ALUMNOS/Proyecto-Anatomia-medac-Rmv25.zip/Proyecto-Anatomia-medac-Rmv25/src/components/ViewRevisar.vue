<template>
    <UserHeader nombre="aqui va cabecera" email="hola mundo" />

    <div class="container-all-muestras" style="margin-top: 120px;">
        <div class="muestras-h2">
            <h2>Nuevo Informe</h2>
        </div>


        <div class="data-container">
            <div class="container-form-muestras">

                <form  @submit.prevent="submitForm">

                    <div class="container-revisar form-muestras">
                        <div class="container-row1-revisar">
                            <p><strong>Código:</strong> {{ code }}</p>
                            <p><strong>Fecha muestra:</strong> {{ dateColected }}</p>
                            <p> correo@medac.es</p> 
                        </div>

                        <div class="container-data-img-revisar">
                            <div class="data-container">
                                <div class="container-row2-revisar">
                                    <div>
                                        <strong>Naturaleza de la muestra</strong>
                                        <select>
                                            <option name="quality" value="" selected>{{ conservation }}</option>
                                            <option name="quality" value="a">otra opcion</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                    </div>
                                    <div class="div2">
                                        <strong>Conservación de muestra</strong>
                                        <select>
                                            <option name="quality" value="" selected>{{ conservation }}</option>
                                            <option name="quality" value="a">otra opcion</option>
                                            <option name="quality" value="b">otra</option>
                                            <option name="quality" value="c">opcion1</option>
                                            <option name="quality" value="d">otro</option>
                                            <option name="quality" value="e">opcion2</option>
                                        </select>
                                    </div>
                                </div>

                                <strong>Descripción citológica o tisular de la muestra</strong>
                                <p class="p-revisar"> {{ quality }}</p>

                                <textarea class="textarea-revisar" rows="13" name="" id="">{{ descQuality }}</textarea>
                                <br>

                                <!-- <p class="p-revisar"> {{ interpretation }}</p> -->
                                <!-- <textarea class="textarea-revisar" rows="10" name="" id="">{{ interpretations }}</textarea> <br> -->

                                <strong>Descripciones</strong>

                                <div v-for="(interpretation, index) in interpretationsArray" :key="index">
                                    <p class="p-revisar"> {{ interpretation.interpretation }}</p>
                                    <textarea class="textarea-revisar" rows="10" name="" id="">{{ interpretation.desc }}</textarea> <br>
                                  </div>
                                  
                                  
                            </div>


                            <div class="container-img-revisar">
                                <div v-for="(img, index) in images" :key="index">
                                    <img :src="img" alt="Vista previa de la imagen" /> 
                                    <select v-model="imageAumentos[index]" required>
                                        <option value="null" selected>Tipo de aumento</option>
                                        <option value="x4">x4</option>
                                        <option value="x10">x10</option>
                                        <option value="x40">x40</option>
                                        <option value="x100">x100</option>
                                    </select>
                                </div>
                            </div>
                            
                            
                        </div>

                        <div class="buttons-revisar">
                            <!-- <button class="volver-revisar">Volver</button> -->
                            <button class="enviar-revisar" type="submit">Confirmar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template> 


<script>
import UserHeader from './HeaderUser.vue';
import { ref, onMounted } from 'vue';
import axios from 'axios';
import { useCounterStore } from '../stores/counter.js';

export default {
  components: {
    UserHeader
  },
  props: [
    'code', 'nature', 'dateColected', 'conservation', 'biopsy', 'sede',
    'quality', 'descQuality', 'interpretations', 'imgUrls'
  ],  
  data() {
    return {
      interpretationsArray: [],
      images: [],
      imagesAumentos: []
    };
  },
  mounted() {
    this.interpretationsArray = JSON.parse(this.interpretations);
    const counterStore = useCounterStore();
    this.images = counterStore.images;
    this.imageAumentos = new Array(this.images.length).fill(null);  
    console.log('Props from ViewMuestras:', this.code, this.nature, this.dateColected, this.conservation, this.biopsy, this.sede);
    console.log('Props from ViewMuestras2:', this.quality, this.descQuality, this.interpretationsArray, this.imgUrls);
},


  name: 'ViewRevisar'
};
</script>



<style src="../assets/css/revisar.css"></style>
