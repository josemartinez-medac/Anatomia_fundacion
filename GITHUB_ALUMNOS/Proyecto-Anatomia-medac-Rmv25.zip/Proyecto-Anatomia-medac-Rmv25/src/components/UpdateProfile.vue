<template lang="">

  <UserHeader nombre="aqui va cabecera" email="hola mundo" />

    <div class="profile-page">

        <img src="../assets/Logo.webp" alt="Logo medac" width="200">
        <div class="profile-container">
          <div class="profile-picture">
            <div class="circle"></div>
            <div class="circle" onclick="openFileInput()"> </div>
            <p class="profile-text">Foto de perfil</p>
            <input type="file" id="profilePictureInput" accept="image/*" style="display: none;">
          </div>
          <form class="profile-form">
            <label for="name">Nombre</label><br>
            <input type="text" id="name" name="name" placeholder="Nombre" required>
            <label for="surname">Apellidos</label><br>
            <input type="text" id="surname" name="surname" placeholder="Apellidos" required>
            <label for="email">Email</label><br>
            <input type="email" id="email" name="email" placeholder="Email" required>
            <label for="password">Contraseña</label><br>
            <input type="password" id="password" name="password" placeholder="Contraseña" required>
            <label for="location">Sede</label><br>
            <select id="location" name="location">
              <option value="">Sede</option>
              <option value="Albacete">Albacete</option>
              <option value="Alicante">Alicante</option>
              <option value="Alicante II">Alicante II</option>
              <option value="Almería">Almería</option>
              <option value="Córdoba">Córdoba</option>
              <option value="Leganés">Leganés</option>
              <option value="Granada">Granada</option>
              <option value="Huelva">Huelva</option>
              <option value="Jerez">Jerez</option>
              <option value="Madrid">Madrid</option>
              <option value="Málaga">Málaga</option>
              <option value="Murcia">Murcia</option>
              <option value="Sevilla">Sevilla</option>
              <option value="Valencia">Valencia</option>
              <option value="Zaragoza">Zaragoza</option>
            </select>
          </form>
        </div>
        <div class="buttons">
          <button class="edit-button">Editar perfil</button>
          <button class="home-button">Menú de inicio</button>
          <button class="confirm-button">Confirmar cambios</button>
        </div>
      </div>
</template>





<script>
import UserHeader from './HeaderUser.vue';

export default {
  components: {
    UserHeader
  },
}
</script>



<style src="../assets/css/UpdateProfile.css" ></style>
