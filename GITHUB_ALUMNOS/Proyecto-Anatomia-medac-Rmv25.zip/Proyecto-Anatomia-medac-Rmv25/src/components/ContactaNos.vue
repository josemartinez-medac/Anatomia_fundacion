<template lang="">

  <BasicHeader title="cabecera va aqui" />

  <div class="container-all-muestras">
    <h1>Contacta</h1>
  
    <div class="muestras-h2" id="telefono-container">
      <div class="text-container">
        <h3>Por teléfono</h3>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis eligendi officiis sapiente quidem asperiores.
        </p>
    </div>
    <img src="../assets/telefono.png" alt="Logo Medac" />
    <div class="hover-message">Ver teléfonos</div>
    </div>
  
    <div class="muestras-h2">
        <img src="../assets/mail.png" alt="Logo Medac" />
        <div class="text-container">
            <h3>Por email</h3>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis eligendi officiis sapiente quidem asperiores.
            </p>
        </div>
    </div>
    
    <div class="muestras-h2">
        <div class="text-container">
            <h3>Consulta una tutoría</h3>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis eligendi officiis sapiente quidem asperiores.
            </p>
        </div>
        <img src="../assets/tutoria.jpeg" alt="Logo Medac" />
    </div>
</div>

  
        
</template>




<script>
import BasicHeader from '@/components/BasicHeader.vue';
export default {
  components: {
    BasicHeader
  },
  mounted() {
    document.getElementById("telefono-container").addEventListener("click", this.redirectToURL);
  },
  methods: {
    redirectToURL() {
      window.location.href = "https://medac.es/centros-fp";
    }
  }
}
</script>



<style src="../assets/css/contacta.css"></style>