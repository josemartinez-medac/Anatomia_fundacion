#  Kubernetes Powershell Commands

### `Minikube` installation
- Open Porwellshell (Ansu) MODE ADMIN (if you don't open MODE ADMIN, change `Machine` to `User`)
- Execute next commands:
  * `New-Item -Path 'c:\' -Name 'minikube' -ItemType Directory -Force`
  * `Invoke-WebRequest -OutFile 'c:\minikube\minikube.exe' -Uri 'https://github.com/kubernetes/minikube/releases/latest/download/minikube-windows-amd64.exe' -UseBasicParsing`
  * `$oldPath = [Environment]::GetEnvironmentVariable('Path', [EnvironmentVariableTarget]::Machine)`
  * `if ($oldPath.Split(';') -inotcontains 'C:\minikube'){ [Environment]::SetEnvironmentVariable('Path', $('{0};C:\minikube' -f $oldPath), [EnvironmentVariableTarget]::Machine)}`
- Close Ansu (click X, don't forget) and open Powershell again (in this case,is NOT important the MODE).

### `Kubectl` installation
- Execute next commands to install `kubectl`:
  * minikube start
  * the latest 1.30.0 patch release: `curl.exe -LO "https://dl.k8s.io/release/v1.30.0/bin/windows/amd64/kubectl.exe"`
    >  (OPTIONAL) validate binary: see the documentation in `https://kubernetes.io/docs/tasks/tools/install-kubectl-windows/`
  * if you haven't opened the Powershell MODE ADMIN, you don't need this. You can execute:

    >  `$newPath = [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::User) + ";C:\Program Files\kubectl"`
    
    > `[Environment]::SetEnvironmentVariable("Path", $newPath, [EnvironmentVariableTarget]::User)`
    
    > If you have opened the Powershell MODE ADMIN, change `User` to `Machine`.
    
    > `kubectl version --client` (my versions are: `Client Version: v1.29.1`  `Kustomize Version: v5.0.4-0.20230601165947-6ce0bf390ce3`
    
    > `kubectl get all`
    
    > Output:

`NAME                 TYPE        CLUSTER-IP   EXTERNAL-IP   PORT(S)   AGE
service/kubernetes   ClusterIP    10.96.0.1    <none>       443/TCP   30m
    > minikube status
    > Output:
minikube
type: Control Plane
host: Running
kubelet: Running
apiserver: Running
kubeconfig: Configured
    >  kubectl config --help
    > Output
 
 Modify kubeconfig files using subcommands like "kubectl config set current-context my-context".

 The loading order follows these rules:

  1.  If the --kubeconfig flag is set, then only that file is loaded. The flag may only be set once and no merging takes
place.
  2.  If $KUBECONFIG environment variable is set, then it is used as a list of paths (normal path delimiting rules for
your system). These paths are merged. When a value is modified, it is modified in the file that defines the stanza. When
a value is created, it is created in the first file that exists. If no files in the chain exist, then it creates the
last file in the list.
  3.  Otherwise, ${HOME}/.kube/config is used and no merging takes place.

Available Commands:
  current-context   Display the current-context
  delete-cluster    Delete the specified cluster from the kubeconfig
  delete-context    Delete the specified context from the kubeconfig
  delete-user       Delete the specified user from the kubeconfig
  get-clusters      Display clusters defined in the kubeconfig
  get-contexts      Describe one or many contexts
  get-users         Display users defined in the kubeconfig
  rename-context    Rename a context from the kubeconfig file
  set               Set an individual value in a kubeconfig file
  set-cluster       Set a cluster entry in kubeconfig
  set-context       Set a context entry in kubeconfig
  set-credentials   Set a user entry in kubeconfig
  unset             Unset an individual value in a kubeconfig file
  use-context       Set the current-context in a kubeconfig file
  view              Display merged kubeconfig settings or a specified kubeconfig file

Usage:
  kubectl config SUBCOMMAND [options]`
  
> kubectl config get-contexts
> 

`CURRENT   NAME       CLUSTER    AUTHINFO   NAMESPACE
*         minikube   minikube   minikube   default

> kubectl apply -f your/path/file/or/directory
> Output (Example)
deployment.apps/db created
service/db created
deployment.apps/redis created
service/redis created
deployment.apps/result created
service/result created
deployment.apps/vote created
service/vote created
deployment.apps/worker created
> kubectl cluster-info`

`Kubernetes control plane is running at https://127.0.0.1:41800
CoreDNS is running at https://127.0.0.1:41800/api/v1/namespaces/kube-system/services/kube-dns:dns/proxy`
> Some commands:
- kubectl get all
- kubectl describe the_name
- kubectl explain pod
- 
`KIND:       Pod
VERSION:    v1

DESCRIPTION:
    Pod is a collection of containers that can run on a host. This resource is
    created by clients and scheduled onto hosts.

FIELDS:
  apiVersion    <string>
    APIVersion defines the versioned schema of this representation of an object.
    Servers should convert recognized schemas to the latest internal value, and
    may reject unrecognized values. More info:
    https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#resources

  kind  <string>
    Kind is a string value representing the REST resource this object
    represents. Servers may infer this from the endpoint the client submits
    requests to. Cannot be updated. In CamelCase. More info:
    https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds

  metadata      <ObjectMeta>
    Standard object's metadata. More info:
    https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#metadata

  spec  <PodSpec>
    Specification of the desired behavior of the pod. More info:
    https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status

  status        <PodStatus>
    Most recently observed status of the pod. This data may not be up to date.
    Populated by the system. Read-only. More info:
    https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status
`

 -  kubectl port-forward pod_name_within_pod/ 8088:80
`Forwarding from 127.0.0.1:8088 -> 80
Forwarding from [::1]:8088 -> 80
Handling connection for 8088
Handling connection for 8088
Handling connection for 8088
Handling connection for 8088
Handling connection for 8088
`

> kubectl delete -f .
> 
deployment.apps "db" deleted
service "db" deleted
deployment.apps "redis" deleted
service "redis" deleted
deployment.apps "result" deleted
service "result" deleted
deployment.apps "vote" deleted
service "vote" deleted

## Skaffold
Install skaffold: https://github.com/GoogleContainerTools/skaffold/releases 
ansadd to PATH env in PowerShell MODE ADMIN
> `$path = [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::Machine)`
> 
> `$newPath = "$path;C:\Tools"` (here, your skaffold.exe)
> 
> `[Environment]::SetEnvironmentVariable("Path", $newPath, [EnvironmentVariableTarget]::Machine)`
> 
> skaffold dev


## Examples commands
>> kubectl edit deployment.apps/deployment
> kubectl rollout history deployment.apps/deployment
> kubectl rollout status deployment.apps/deployment
> kubectl rollout undo deployment.apps/deployment
> 
