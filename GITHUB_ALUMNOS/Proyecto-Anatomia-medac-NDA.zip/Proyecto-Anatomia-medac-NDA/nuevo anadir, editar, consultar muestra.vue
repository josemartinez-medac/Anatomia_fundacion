<template>
<div id="app">
    <div class="todo">
<div class="container0">
<div>
  <!--<div class="centro"></div>-->
    <div class="container1">
      <div class="bloq">
        <div class="titulo">Añadir nueva muestra</div>
          <div class="texto">Lorem ipsum 
          </div>
            <div class="botones">
            <button class="btn1">Comenzar →</button>
            <!--<button class="btn2">Saber más...</button>-->
            </div>
      </div>
      <div class="img"><img  class="img" src="imagenes/tubos.png" alt="muestras en tubo de ensayo"></div>
      </div>
    </div>

    <div class="container1">
      <div class="bloq">
        <div class="titulo">Editar muestra</div>
          <div class="texto">Lorem ipsum 
          </div>
            <div class="botones">
            <button class="btn1">Comenzar →</button>
            <!--<button class="btn2">Saber más...</button>-->
            </div>
      </div>
      <div class="img"><img  class="img" src="imagenes/variostubos.png" alt="muestras en tubo de ensayo"></div>
      </div>
    </div>


  <div class="container1">
      <div class="bloq">
        <div class="titulo">Consultar muestra</div>
        <div class="texto">Lorem ipsum </div>
        <div class="botones">
          <button class="btn1">Comenzar →</button>
          <!--<button class="btn2">Saber más...</button>-->
        </div>
      </div>
      <div class="img"><img  class="img" src="imagenes/microscopios.jpg" alt="técnicos analizan muestras al microscopio"></div>
      </div>
  </div>
  </div>
</template>

<script></script>

<style scoped>
.todo {
  background-color: rgb(245, 245, 245);
  color: rgb(0, 70, 118);
  font-family: inter;
}

.container0{
margin-top: 40px;
}

.container1 {
  display: flex;
  margin: auto;
  background-color: white;
  color: rgb(0, 70, 118);
  margin-top: 2vh;
  padding: 1%;
  border-radius: 20px;
  height: 20vh;
  width: 80vw;
  align-content: left;
  flex-flow: column;
  flex-wrap: wrap;
}

.titulo {
  display: flex;
  text-align: left;
  height: 4vh;
  width: 30vw;;
  line-height: 3vh;
  font-size: 4vh;
  font-weight: bold;
  margin-left: 5vw;
}

.texto {
  display: flex;
  width: 20vw;
  text-align: justify;
  margin-top: 0vh;
  margin-left: 5vw;
  font-size: 2.5vh;
}

.botones {
  display: flex;
  flex-direction: row;
  text-align: justify;
  font-size: 1.5vh;
  place-content: flex-start;
  margin: auto;
}

.btn1 {
  width: 11vw;
  height: 7vh;
  margin-top: 3vh;
  margin-left: 5vw;
  background-color: rgb(0, 70, 118);
  color: rgb(245, 245, 245);
  border-radius: 8px;
}

.img {
  border-radius: 10px;
  vertical-align: middle;
  margin-right: 1vw;
  max-block-size: 19vh;
  display: flex;
  border-radius: 10px;
  vertical-align: middle;
  flex-direction: row;
  place-content: left;
  align-self: center;
  flex-flow: row wrap;
  height: 110vh;
  width: 80wv;
}

</style>