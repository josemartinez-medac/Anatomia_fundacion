<template>
    

  <div id="app" v-cloak>

    <div><h2>Elige tu centro</h2></div>
    <div class="botones">
      <!--<button @click="cambiarImagen('todos')">Todos</button>-->
      <button class="boton" @mouseover="cambiarImagen('albacete')" @mouseleave="cambiarImagen('todos')">Albacete</button>
      <button class="boton" @mouseover="cambiarImagen('alicante')" @mouseleave="cambiarImagen('todos')">Alicante</button>
      <button class="boton" @mouseover="cambiarImagen('alicante2')" @mouseleave="cambiarImagen('todos')">Alicante II</button>
      <button class="boton" @mouseover="cambiarImagen('almeria')" @mouseleave="cambiarImagen('todos')">Almería</button>
      <button class="boton" @mouseover="cambiarImagen('córdoba')" @mouseleave="cambiarImagen('todos')">Córdoba</button>
      <button class="boton" @mouseover="cambiarImagen('granada')" @mouseleave="cambiarImagen('todos')">Granada</button>
      <button class="boton" @mouseover="cambiarImagen('huelva')" @mouseleave="cambiarImagen('todos')">Huelva</button>
      <button class="boton" @mouseover="cambiarImagen('jerez')" @mouseleave="cambiarImagen('todos')">Jerez</button>
      <button class="boton" @mouseover="cambiarImagen('leganes')" @mouseleave="cambiarImagen('todos')">Leganés</button>
      <button class="boton" @mouseover="cambiarImagen('madrid')" @mouseleave="cambiarImagen('todos')">Madrid</button>
      <button class="boton" @mouseover="cambiarImagen('málaga')" @mouseleave="cambiarImagen('todos')">Málaga</button>
      <button class="boton" @mouseover="cambiarImagen('murcia')" @mouseleave="cambiarImagen('todos')">Murcia</button>
      <button class="boton" @mouseover="cambiarImagen('sevilla')" @mouseleave="cambiarImagen('todos')">Sevilla</button>
      <button class="boton" @mouseover="cambiarImagen('valencia')" @mouseleave="cambiarImagen('todos')">Valencia</button>
      <button class="boton" @mouseover="cambiarImagen('zaragoza')" @mouseleave="cambiarImagen('todos')">Zaragoza</button>
    </div>

    <div>      
      <img id="mapa" v-if="imagenActual === 'todos'" src="imagenes/todos.png" alt="todos">
      <img id="mapa" v-if="imagenActual === 'albacete'" src="imagenes/albacete.png" alt="Albacete">
      <img id="mapa" v-if="imagenActual === 'alicante'" src="imagenes/alicante.png" alt="Alicante">
      <img id="mapa" v-if="imagenActual === 'alicante2'" src="imagenes/alicante2.png" alt="Alicante II">
      <img id="mapa" v-if="imagenActual === 'almeria'" src="imagenes/almeria.png" alt="Almería">
      <img id="mapa" v-if="imagenActual === 'córdoba'" src="imagenes/cordoba.png" alt="Córdoba">
      <img id="mapa" v-if="imagenActual === 'granada'" src="imagenes/granada.png" alt="Granada">
      <img id="mapa" v-if="imagenActual === 'huelva'" src="imagenes/huelva.png" alt="Huelva">
      <img id="mapa" v-if="imagenActual === 'jerez'" src="imagenes/jerez.png" alt="Jerez">
      <img id="mapa" v-if="imagenActual === 'leganes'" src="imagenes/leganes.png" alt="Leganés">
      <img id="mapa" v-if="imagenActual === 'madrid'" src="imagenes/madrid.png" alt="Madrid">
      <img id="mapa" v-if="imagenActual === 'málaga'" src="imagenes/malaga.png" alt="Málaga">
      <img id="mapa" v-if="imagenActual === 'murcia'" src="imagenes/murcia.png" alt="Murcia">
      <img id="mapa" v-if="imagenActual === 'sevilla'" src="imagenes/sevilla.png" alt="Sevilla">
      <img id="mapa" v-if="imagenActual === 'valencia'" src="imagenes/valencia.png" alt="Valencia">
      <img id="mapa" v-if="imagenActual === 'zaragoza'" src="imagenes/zaragoza.png" alt="Zaragoza">
    </div>
  </div>

</template>

  <script>
    const App = {
      data() {
        return {
          imagenActual: 'todos'
        };
      },
      methods: {
        cambiarImagen(nuevaImagen) {
          this.imagenActual = nuevaImagen;
        }
      }
    };
    
    Vue.createApp(App).mount('#app');
  </script>

  <style scoped>
.body {
    background-color: white;
    color: rgb(0,70,118);
    font-family: inter;
}

[v-cloak] {
  display: none;
}

.titulo{
  font-size: 30px;
  text-align: center;
  margin-top: 10px;
  margin-bottom: 20px;
}

#app{
  background-color: (245,245,245);
  display: flex;
  justify-content: center;
}

.botones{
  display: inline-block;
  column-count: 3;
  width: 25%;
  margin-top: 10%;
  margin-left: 20vw;
  text-align: center;
}

.boton {
  display: flex;
  flex-direction: column;
  width: 7vw;
  background-color: rgb(0,70,118); 
  color: rgb(245,245,245);
  margin-bottom: 0.5vh;
  padding: 1vh 1vw;
  border-radius: 10px;
}

#mapa{
  width: 45vw;
  height: auto;
  margin-top: 10%;
  margin-right: 10vw;
}

</style>
