from django.db.models import Model, CharField,ForeignKey,RESTRICT,TextField,DateField,ImageField, IntegerField
from django.contrib.auth.models import User

class Organo (Model):
    organo=CharField(verbose_name='Órgano', max_length=30, unique=True)
    codigo=CharField(verbose_name='Código', max_length=3, unique=True)
    def __str__(self) -> str:
        return f"{self.organo}"
class Sede (Model):
    sede=CharField(verbose_name='Sede', max_length=11, unique=True)
    codigo=CharField(verbose_name='Código', max_length=4, unique=True)
    def __str__(self) -> str:
        return f"{self.sede}"
class Naturaleza(Model):
    codigo=CharField(verbose_name='Código', max_length=2, unique=True)
    naturaleza=CharField(verbose_name='Naturaleza', max_length=50, unique=True)
    def __str__(self) -> str:
        return f"{self.naturaleza}"
class Tipo(Model):
    tipo=CharField(verbose_name='Tipo', max_length=14, unique=True)
    def __str__(self) -> str:
        return f"{self.tipo}"
class CodificacionInterpretacion(Model):
    organo=ForeignKey(Organo,on_delete=RESTRICT, verbose_name='Órgano', db_column='organo', to_field='organo', default='Corazón')
    naturaleza=ForeignKey(Naturaleza, on_delete=RESTRICT, verbose_name='Naturaleza', db_column='naturaleza', to_field='naturaleza', default='Biopsia')
    tipo=ForeignKey(Tipo, on_delete=RESTRICT, db_column='tipo', to_field='tipo', verbose_name='Tipo', default='Calidad')
    codigo=CharField(unique=True, verbose_name='Código', max_length=7)
    descripcion=TextField(verbose_name='Descripción')
    class Meta:
        verbose_name='Codificación de Interpretación'
        verbose_name_plural='Codificaciones de Interpretación'
    def __str__(self) -> str:
        return f"{self.codigo}"
class Formato (Model):
    formato=CharField(verbose_name='Formato', max_length=20, unique=True)
    def __str__(self) -> str:
        return f"{self.formato}"
class Estado(Model):
    estado=CharField(unique=True, verbose_name='Estado', max_length=20)
    comentario=TextField(verbose_name='Comentario', null=True, blank=True)
    def __str__(self) -> str:
        return f"{self.estado}"
class Muestra(Model):
    fecha_recepcion=DateField()
    naturaleza=ForeignKey(Naturaleza, verbose_name='Naturaleza', on_delete=RESTRICT, db_column='naturaleza', to_field='codigo', default='Semen')
    formato=ForeignKey(Formato, on_delete=RESTRICT,verbose_name='Formato', db_column='formato', to_field='formato', default='Fresco')
    organo=ForeignKey(Organo, verbose_name='Órgano', on_delete=RESTRICT, db_column='organo', to_field='organo', default='Riñón')
    sede=ForeignKey(Sede,verbose_name='Sede', on_delete=RESTRICT, db_column='sede', to_field='codigo', default='C')
    estado=ForeignKey(Estado, verbose_name='Estado', on_delete=RESTRICT,db_column='estado', to_field='estado', default='Pendiente de revisar')
    username=ForeignKey(User, verbose_name='Usuario', on_delete=RESTRICT, db_column="username",to_field='username',null=False, default='admin')
    def __str__(self):
        return f"{self.fecha_recepcion}"
class Aumento(Model):
    zoom=CharField(verbose_name="Aumento", max_length=4, unique=True, default="x4")
    def __str__(self):
        return f"{self.zoom}"
class Imagen(Model):
    imagen=ImageField(upload_to='img', default="camera.png", verbose_name='Imagen')
    zoom=ForeignKey(Aumento,on_delete=RESTRICT,db_column='zoom', to_field='zoom', default='x4')
    class Meta:
        verbose_name='Imagen'
        verbose_name_plural='Imágenes'
    def __str__(self):
        return f"{self.imagen}"